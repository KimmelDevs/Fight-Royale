NIVA — SNOW PUPPET MASTER (V1)
=============================

Run in your Fight Royale web/ folder (beside package.json):

  py install_snow_puppet_master.py
  npx tsc --noEmit
  npm run dev

The script changes ONLY:
  src/game/roster.ts
  src/game/kits.ts
  src/game/game.ts
  src/ui/Select.tsx

It makes timestamped backups, checks all anchors before writing, and is safe to run again.

NEW FIGHTER
  Niva / Snow Puppet Master
  Temporary VRM: marina.vrm (keeps Marina unchanged)
  Later replace vrm: "marina" with vrm: "niva" once you have public/models/niva.vrm.

KIT (starting balance)
  Light: existing 3-hit mage ice-bolt combo
  Heavy: charged ice projectile, 170 base damage
  Z — Snowglass Shield: 2 sec PvP / 4 sec survival; 11 sec cooldown
  X — Frost Marionette: one snow puppet; successful blast freezes 1.35 sec; 9 sec cooldown
  C — Glacier Meteor: ice-colored meteor, 245 damage, slow on hit; 15 sec cooldown
  V — Snowfall Parade: three snow puppets. They SLOW but DO NOT FREEZE;
      each explodes independently; 17 sec cooldown. V is bonus shop skill.

Puppets pursue enemies, explode on contact or timeout, and expire on round reset/owner KO.
Server/host applies hits and statuses; client displays replicated snow puppets.
Normal blocks, wards and hit restrictions are respected.

IMPORTANT
  - Apply 20261106062000_add_niva_snow_puppet_master.sql via your Supabase
    SQL editor if signed-in players need to purchase Niva.
  - The SQL file updates the allowlist. If you added other character IDs,
    include them before applying it.
  - This patch was tested against SAVED project source files, not against
    any unuploaded local edits made after them. Run TypeScript checks locally.
  - The ice shield is a full ward based on the game's existing mage system.
