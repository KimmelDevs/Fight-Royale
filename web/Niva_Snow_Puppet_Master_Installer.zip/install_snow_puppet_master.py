#!/usr/bin/env python3
"""Niva — Snow Puppet Master installer for Fight Royale.

Run in web/ next to package.json. Patches are checked in memory before writes.
Copies .bak files of the original sources; rerunning is harmless.
"""
from pathlib import Path
from datetime import datetime
import sys

ROOT = Path.cwd()
NAMES = ['src/game/roster.ts', 'src/game/kits.ts', 'src/game/game.ts', 'src/ui/Select.tsx']
if not (ROOT / 'package.json').is_file():
    sys.exit('Run from the web/ directory beside package.json. Nothing changed.')
for n in NAMES:
    if not (ROOT / n).is_file():
        sys.exit(f'Missing {n}. Nothing changed.')
old = {n: (ROOT / n).read_text(encoding='utf-8') for n in NAMES}
new = old.copy()
if 'SNOW_PUPPET_MASTER_V1' in old['src/game/game.ts']:
    print('Snow Puppet Master is already installed. Nothing changed.')
    sys.exit(0)

def insert_once(name, anchor, content, before=True):
    source = new[name]
    hits = source.count(anchor)
    if hits != 1:
        raise RuntimeError(f'Preflight failed: {name} expected one anchor, found {hits}: {anchor[:96]!r}. No changes made.')
    new[name] = source.replace(anchor, (content + '\n' + anchor) if before else (anchor + '\n' + content), 1)

try:
    R, K, G, U = NAMES
    if 'id: "niva"' in new[R] or 'element === "frost"' in new[K]:
        raise RuntimeError('Niva appears partially installed. Nothing changed; send your current files for a safe repair.')

    roster = r'''  // SNOW_PUPPET_MASTER_V1: temporary Marina VRM, independently selectable fighter.
    { id: "niva", title: "Snow Puppet Master", role: "Mage - Ice Puppeteer",
      desc: "Commands living snow puppets: an ice shield, a freezing marionette, a falling ice meteor, and three slowing explosive puppets.",
      stats: { power: 4, speed: 3, range: 5, defense: 3 },
      look: { name: "Niva", body: "f", vrm: "marina", kit: "mage", element: "frost", outfit: "mage", style: "bob", hat: "beret",
        hair: "#e6f5ff", hair_shade: "#8abfe2", iris_top: "#3276af", iris_bottom: "#b4efff", eye_dark: "#163c6a",
        tunic: "#244b86", band: "#e6f8ff", pants: "#d8eefa", boots: "#25365d", metal: "#bedce7", trim: "#e4faff",
        cape: "#85bce1", cape_bottom: "#e9fcff", glow: "#9cddff", shield: "#9cddff", emblem: "#e8f8ff" } },'''
    # Add just before roster closing bracket, preserving all existing characters.
    insert_once(R, '\n];\n\nexport function resolveEnemy(', roster)

    frost_bonus = r'''      if (element === "frost") return a({ name: "Snowfall Parade", desc: "Summon three snow puppets. Each chases an enemy and explodes in slowing frost (no freezing).", cd: 17,
        type: "snow_puppet", style: "slow", wind: 0.30, recover: 0.45, dmg: 58, guard: 16, knock: 1.2, stun: 0.1,
        count: 3, speed: 3.0, radius: 1.05, duration: 5.0, effect: "slow", effect_t: 2.8, effect_p: 0.55,
        pose_w: "mh_w", pose_s: "m3_s" });'''
    insert_once(K, '      if (element === "fire") return a({ name: "Inferno Ring"', frost_bonus)

    frost_kit = r'''  // SNOW_PUPPET_MASTER_V1: the snow summons are persistent arena objects, not generic circle FX.
  if (element === "frost") {
    t.heavy = a({ type: "projectile", wind: 0.22, active: 0.05, recover: 0.5, dmg: 170, guard: 47, knock: 4.5, stun: 0.48, heavy: true,
      speed: 12, size: 1.7, style: "bolt", pose_w: "mh_w", pose_s: "mh_s" });
    t.z = a({ name: "Snowglass Shield", desc: "Create a protective ice shield for 2 seconds in PvP (4 seconds in survival).", cd: 11,
      type: "buff", mode: "ward", duration: 4, wind: 0.12, recover: 0.28, pose_w: "mh_w", pose_s: "m3_s" });
    t.x = a({ name: "Frost Marionette", desc: "Summon one snow puppet that chases an enemy and bursts, freezing on a successful hit.", cd: 9,
      type: "snow_puppet", style: "freeze", wind: 0.26, recover: 0.42, dmg: 77, guard: 24, knock: 0.9, stun: 0.2,
      count: 1, speed: 3.8, radius: 0.95, duration: 5.5, effect: "paralyze", effect_t: 1.35,
      pose_w: "m2_w", pose_s: "m2_s" });
    t.c = a({ name: "Glacier Meteor", desc: "A large ice meteor falls onto the marked position, damaging and slowing anyone caught beneath it.", cd: 15,
      type: "strike", style: "meteor", wind: 0.36, recover: 0.65, dmg: 245, guard: 65, knock: 5.5, stun: 0.65,
      heavy: true, delay: 0.85, radius: 2.1, effect: "slow", effect_t: 2.0, effect_p: 0.65,
      pose_w: "mh_w", pose_s: "mh_s" });
    return t;
  }
'''
    # Insert into mage() immediately before its fire/electric/water skill-selection.
    mage_start = new[K].find('function mage(element: string): Record<string, Attack> {')
    if mage_start < 0: raise RuntimeError('mage() declaration missing; no changes made.')
    mage_tail = new[K][mage_start:]
    marker = '  if (element === "fire") {\n    t.heavy ='
    if mage_tail.count(marker) != 1:
        raise RuntimeError('mage() skill selection has changed; no changes made.')
    idx = mage_start + mage_tail.index(marker)
    new[K] = new[K][:idx] + frost_kit + new[K][idx:]

    # Her mage kit shares movement poses with Marina but has distinct skill descriptions.
    old_control = '{CONTROLS[ch.look.kit]}'
    if new[U].count(old_control) != 1:
        raise RuntimeError('PreparePanel control tooltip changed; no changes made.')
    new[U] = new[U].replace(old_control,
        '{ch.look.element === "frost" ? "Tap: ice bolts - Hold: charged ice spell - Z: Snowglass Shield - X: Freezing Puppet - C: Glacier Meteor - V: Three slowing puppets" : CONTROLS[ch.look.kit]}', 1)

    snow_types = r'''// SNOW_PUPPET_MASTER_V1 — persistent snow summons (host-controlled, guest visuals only).
interface SnowPuppet {
  id: number; owner: Fighter | null; team: number; atk: Attack | null; power: number;
  pos: THREE.Vector3; targetId: number; life: number; age: number;
  mesh: THREE.Group; mode: "freeze" | "slow";
}

function buildSnowPuppetMesh(mode: "freeze" | "slow"): THREE.Group {
  const g = new THREE.Group();
  const snow = new THREE.MeshLambertMaterial({ color: "#edfaff" });
  const shadow = new THREE.MeshLambertMaterial({ color: "#b9d9ee" });
  const ice = new THREE.MeshLambertMaterial({ color: mode === "freeze" ? "#6ac9ff" : "#9fe1ee" });
  const ink = new THREE.MeshBasicMaterial({ color: "#1d446c" });
  const body = new THREE.Mesh(new THREE.SphereGeometry(0.36, 14, 10), snow);
  body.position.y = 0.39;
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.25, 14, 10), snow);
  head.position.y = 0.94;
  const waist = new THREE.Mesh(new THREE.TorusGeometry(0.29, 0.048, 7, 18), ice);
  waist.rotation.x = Math.PI / 2;
  waist.position.y = 0.60;
  g.add(body, head, waist);
  for (const side of [-1, 1]) {
    const eye = new THREE.Mesh(new THREE.SphereGeometry(0.046, 8, 6), ink);
    eye.position.set(side * 0.10, 0.99, 0.22);
    const arm = new THREE.Mesh(new THREE.ConeGeometry(0.09, 0.46, 6), shadow);
    arm.position.set(side * 0.38, 0.65, 0);
    arm.rotation.z = side * 1.1;
    g.add(eye, arm);
  }
  const crown = new THREE.Mesh(new THREE.ConeGeometry(mode === "freeze" ? 0.23 : 0.18, 0.37, 5), ice);
  crown.position.y = 1.31;
  g.add(crown);
  const gem = new THREE.Mesh(new THREE.OctahedronGeometry(0.10, 0), ice);
  gem.position.set(0, 0.79, 0.32);
  g.add(gem);
  const aura = new THREE.Mesh(new THREE.TorusGeometry(0.43, 0.025, 5, 28), new THREE.MeshBasicMaterial({ color: "#8ddcff", transparent: true, opacity: 0.65 }));
  aura.rotation.x = Math.PI / 2;
  aura.position.y = 0.09;
  g.add(aura);
  g.scale.setScalar(mode === "freeze" ? 1.0 : 0.82);
  return g;
}
'''
    insert_once(G, 'function buildTrap(kind: string, color: string): THREE.Group {', snow_types)
    insert_once(G, '  traps: Trap[] = [];', '  private snowPuppets: SnowPuppet[] = [];', before=False)
    insert_once(G, '    this.traps = [];', '''    // SNOW_PUPPET_MASTER_V1: clear summons on the next round/rematch.
    for (const p of this.snowPuppets) this.disposeSnowPuppet(p);
    this.snowPuppets = [];''', before=False)
    insert_once(G, '    this.updateTraps(dt);', '    this.updateSnowPuppets(dt);', before=False)
    insert_once(G, '      case "mine": this.plantMine(f, a); break;', '      case "snow_puppet": this.summonSnowPuppets(f, a); break;')

    methods = r'''  // SNOW_PUPPET_MASTER_V1: spawn, move, and resolve real snow minions. Never damage allies.
  private disposeSnowPuppet(p: SnowPuppet) {
    this.scene.remove(p.mesh);
    p.mesh.traverse((o) => {
      const mesh = o as THREE.Mesh;
      if (!mesh.isMesh) return;
      mesh.geometry.dispose();
      for (const mat of Array.isArray(mesh.material) ? mesh.material : [mesh.material]) mat.dispose();
    });
  }

  private makeSnowPuppet(id: number, owner: Fighter | null, team: number, atk: Attack | null,
      power: number, pos: THREE.Vector3, targetId: number, mode: "freeze" | "slow", duration: number) {
    if (this.snowPuppets.some(p => p.id === id)) return;
    const mesh = buildSnowPuppetMesh(mode);
    mesh.position.copy(pos);
    this.scene.add(mesh);
    this.snowPuppets.push({ id, owner, team, atk, power, pos, targetId, mode, life: duration, age: 0, mesh });
  }

  private summonSnowPuppets(f: Fighter, a: Attack) {
    const target = f.opponent && !f.opponent.isDown() ? f.opponent : this.enemiesOf(f)[0];
    const forward = new THREE.Vector3(Math.sin(f.root.rotation.y), 0, Math.cos(f.root.rotation.y));
    const right = new THREE.Vector3(forward.z, 0, -forward.x);
    for (let i = 0; i < a.count; i++) {
      const offset = i - (a.count - 1) / 2;
      const pos = f.root.position.clone().addScaledVector(forward, 1.05).addScaledVector(right, this.plat ? 0 : offset * 1.05);
      if (!this.plat) pos.y = 0; // Ground-level even when the opponent is airborne.
      const id = this.nextId++;
      const mode: "freeze" | "slow" = a.style === "freeze" ? "freeze" : "slow";
      this.makeSnowPuppet(id, f, f.team, a, f.atkPower, pos, target?.id ?? -1, mode, a.duration);
      this.emit(["snowPuppet", id, f.id, f.team, pos.toArray(), target?.id ?? -1, mode, a.duration]);
      this.fxp("motes", pos.clone().add(new THREE.Vector3(0, 0.7, 0)), "#d6f8ff", 11);
    }
    this.snd("splash", 0.55);
  }

  private finishSnowPuppet(p: SnowPuppet, exploded: boolean) {
    if (!this.snowPuppets.includes(p)) return;
    if (exploded && this.cfg.role !== "client" && p.owner && p.atk) {
      const mid = p.pos.clone().add(new THREE.Vector3(0, 0.7, 0));
      this.fxp("explosion", mid, p.mode === "freeze" ? "#72caff" : "#a6eaff", p.atk.radius);
      this.fxp("motes", mid, "#e3f9ff", 18);
      this.fxp("ring", mid, "#b3ebff", p.atk.radius, 0.25, 0.75);
      for (const d of this.enemiesOf(p.owner)) {
        const to = d.root.position.clone().sub(p.pos);
        const height = Math.abs(to.y);
        to.y = 0;
        if (to.length() > p.atk.radius + d.radius * 0.5 || (this.plat && height > 1.6)) continue;
        if (!this.plat && d.airborne()) continue;
        const dir = to.lengthSq() > 0.0001 ? to.normalize() : new THREE.Vector3(1, 0, 0);
        // Standard receiveHit handles guarding, parrying, wards and status resistance.
        this.applyHit(p.owner, d, p.atk, p.power, d.chest(), dir, true);
      }
    }
    this.disposeSnowPuppet(p);
    this.snowPuppets = this.snowPuppets.filter(x => x !== p);
    if (this.cfg.role !== "client") this.emit(["snowPuppetEnd", p.id]);
  }

  private updateSnowPuppets(dt: number) {
    for (const p of [...this.snowPuppets]) {
      p.life -= dt;
      p.age += dt;
      if (this.cfg.role !== "client" && (!p.owner || p.owner.isDown() || this.roundOver)) {
        this.finishSnowPuppet(p, false);
        continue;
      }
      let target = this.entities.get(p.targetId);
      if (!target || target.isDown() || target.team === p.team) {
        target = p.owner ? this.enemiesOf(p.owner)[0] : undefined;
        if (target) p.targetId = target.id;
      }
      if (target) {
        const delta = target.root.position.clone().sub(p.pos);
        if (!this.plat) delta.y = 0;
        const distance = delta.length();
        const speed = p.atk?.speed ?? (p.mode === "freeze" ? 3.8 : 3.0);
        if (distance > 0.05) {
          const direction = delta.multiplyScalar(1 / distance);
          p.pos.addScaledVector(direction, Math.min(Math.max(0, distance - 0.45), speed * dt));
          p.mesh.rotation.y = Math.atan2(direction.x, direction.z);
        }
        // On contact, this puppet explodes exactly once. Other puppets are independent.
        if (this.cfg.role !== "client" && distance < 0.95) {
          this.finishSnowPuppet(p, true);
          continue;
        }
      }
      p.mesh.position.copy(p.pos).add(new THREE.Vector3(0, Math.sin(p.age * 7 + p.id) * 0.06, 0));
      if (p.life <= 0) this.finishSnowPuppet(p, this.cfg.role !== "client");
    }
  }
'''
    insert_once(G, '  private plantMine(f: Fighter, a: Attack) {', methods)

    # In client / late-joiner event replication, puppet visual state is identical to host.
    event_handlers = r'''      case "snowPuppet": {
        // Guest renders a moving snowman; damage and freeze/slow are host-authoritative.
        this.makeSnowPuppet(ev[1], null, ev[3], null, 0, v3(ev[4]), ev[5], ev[6], ev[7]);
        break;
      }
      case "snowPuppetEnd": {
        const p = this.snowPuppets.find(x => x.id === ev[1]);
        if (p) this.finishSnowPuppet(p, false);
        break;
      }
'''
    insert_once(G, '      case "trap": {', event_handlers)
    late_sync = r'''    // SNOW_PUPPET_MASTER_V1: late joiners also see currently active snow minions.
    for (const p of this.snowPuppets) ev.push(["snowPuppet", p.id, p.owner?.id ?? -1, p.team, p.pos.toArray(), p.targetId, p.mode, p.life]);'''
    insert_once(G, '    this.net?.sendTo(peer, { t: "sync", e: ev, s: [this.wave, this.kills, this.phase] });', late_sync)

    ice_shield_fx = r'''      if (f.look.element === "frost") {
        this.fxp("ring", f.root.position.clone().setY(this.plat ? f.root.position.y : 0), "#c2f1ff", 1.4, 0.3, 0.9);
        this.fxp("motes", f.chest(), "#e9fcff", 24);
        this.fxp("num", f.chest().add(new THREE.Vector3(0, 0.75, 0)), "SNOWGLASS", "#e5f9ff", 0.8);
      }'''
    insert_once(G, '      this.fxp("bubble", f.id, dur);', ice_shield_fx, before=False)
except Exception as exc:
    sys.exit(f'{exc}')

# All source checks passed. Copy backups only now; do not touch anything on preflight failure.
stamp = datetime.now().strftime('%Y%m%d_%H%M%S')
for n in NAMES:
    if new[n] == old[n]:
        continue
    p = ROOT / n
    backup = p.with_name(p.name + f'.before_snow_{stamp}.bak')
    backup.write_text(old[n], encoding='utf-8')
    p.write_text(new[n], encoding='utf-8')
    print(f'PATCH {n} (backup: {backup.name})')
print('DONE: Niva installed with Snowglass Shield, Frost Marionette, Glacier Meteor, and Snowfall Parade.')
print('Temporary VRM: public/models/marina.vrm. Run `npx tsc --noEmit` and `npm run dev`.')
print('Run the bundled Supabase migration in SQL Editor for signed-in purchases.')
