-- Niva: Snow Puppet Master. Run AFTER previous character migrations.
-- Existing named and legacy IDs from the Zarek/Kaizen migrations are preserved.
-- If you've added your own characters, include their IDs here too.
CREATE OR REPLACE FUNCTION public.valid_character(c text)
RETURNS boolean
LANGUAGE sql
IMMUTABLE
AS $$
  SELECT c = ANY (ARRAY[
    'aster','vesper','garrick','kaede','ember','marina',
    'nyx','rook','gale','bob','kira','raven','ash',
    'veyr','zarek','kaizen','niva',
    'volta','sylva','leon','sakura','yuki','bruno'
  ])
$$;
