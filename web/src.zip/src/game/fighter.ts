// AI_ROOK_NESA_KIRA_MERGED_V1_20261108
// KAIZEN_PARRY_SPEED_MINUS_10_PERCENT_20261107_V1
// BALANCE_KIRA_KAEDE_PATTERN_AI_AIR_ICON_20261107_V1
// FOURTH_SKILL_V_MASTER_AI_TWO_ROW_ROSTER_20261107_V1
// MARINA_RAVEN_ZAREK_BOB_ABILITIES_20261107_V1
// FIGHT_ROYALE_BULLET_SWORDPLAY_GARRICK_RESOLVE_V1
// KAIZEN_PARRY_SPIN_SLOW_REVERSE_V10
// FIGHT_ROYALE_KAIZEN_MOBILE_SPIN_V8
// FIGHT_ROYALE_GARRICK_BOB_KAIZEN_ROOK_V7
// FIGHT_ROYALE_NYX_CAMERA_CONTINUOUS_DODGE_20261107_V1
// FIGHT_ROYALE_PARRY_SPIN_COUNTERS_V2
// FIGHT_ROYALE_PARRY_SPIN_COUNTERS_V1
// NESA_HEART_SMASH_V4
// FIGHT_ROYALE_GROUNDED_AIR_SLICES_V1
// FIGHT_ROYALE_WEIGHTED_KNOCKDOWN_WAKEUP_V1
// FIGHT_ROYALE_SIGNATURE_POSES_V2
// FIGHT_ROYALE_VICTORY_HIGHLIGHTS_V1
// FIGHT_ROYALE_PERFECT_DODGE_V1_NOV07
// ASTER_TANK_ONLY_V2_20261107
// MELEE_PROJECTILE_SPRINT_V1_NOV06
// CONTINUOUS_PARRY_AI_V4_NOV06
// CONTINUOUS_COMBAT_ASTER_EMBER_V3_NOV06
// Playable fighter. A brain (local input, AI, or a remote player's inputs) fills `intent`
// every frame:
//   attack tap (release < HOLD_T)  -> normal attack, chains into the kit's combo
//   attack hold, then release      -> charged attack (stronger the longer it charged)
//   block hold                     -> block; the first parryWindow seconds parry
//   jump                           -> jump (dodges ground strikes and low projectiles)
//   skill "z" / "x" / "c"          -> skill, if off cooldown
// The arena gets `onSwing` when an attack reaches its active frame and resolves its effect.
// On network clients the fighter is a puppet: it only mirrors state sent by the host.
// With a `stage` set (duel / team modes) it plays as a side-view platform fighter: moves on
// the X axis, double jumps, lands on platforms, and takes damage % instead of losing HP. The
// higher the %, the farther hits launch it; flying past the blast zone costs a stock.
import { StatusSet, type StatusKind } from "./status";
import * as THREE from "three";
import { FighterModel } from "./model";
import { Trail } from "./fx";
import * as Kits from "./kits";
import { presentationPose } from "./presentation";
import type { Attack, Pose } from "./kits";
import type { Look } from "./roster";
import { emblemBonus, DEFAULT_LOADOUT } from "./economy";

/** Long, individually-timed attacks keep their choreography after parries/clashes.
 * Basic light chains and single-hit skills intentionally keep ordinary reactions. */
export const CONTINUOUS_STYLES = new Set([
  "sickle_carrion", "glaive_cyclone", "glaive_serpent", "glaive_phantom", "glaive_infinite",
  "chain_razor_cyclone", "chain_death_spiral", "chain_carousel", "chain_return",
  "cyclone_kick_v2", "iron_tempest", "phantom_rush",
]);

export enum S { IDLE, ATTACK, CHARGE, BLOCK, HITSTUN, STAGGER, KO, WIN, KNOCKDOWN, WAKEUP }

export const HOLD_T = 0.22;
export const CHARGE_MAX = 0.9;
const ENGAGE = 1.45;
const MIN_DIST = 0.95;
const GRAVITY = 22;
const GUARD_REGEN = 30;
// FIGHT_ROYALE_GUARD_REGEN_DAMAGE_DELAY_V1: continuous damage-free seconds before guard can regenerate.
const GUARD_REGEN_DAMAGE_DELAY = 2.0;

/** One-way platforms (solid = main stage: can't drop through, has side walls). */
export interface Plat { x0: number; x1: number; y: number; solid: boolean }
export interface Stage { plats: Plat[]; blast: { l: number; r: number; b: number; t: number }; respawn: THREE.Vector3 }
export const STOCKS = 3;
/** After a ranged combo's last hit, normal attacks rest this long (per kit). */
export const RANGED_COMBO_REST: Record<string, number> = { mage: 1.2, bow: 1.3, bomb: 1.2 };
/** Berserk (rage buff) damage multiplier. */
export const RAGE_MULT = 1.2;
/** Re-stuns within this window are shortened (diminishing returns). */
const STUN_DR_WINDOW = 3;
const STUN_DR = 0.6;
const PCT_PER_DMG = 0.07;

export interface Intent { attack: boolean; block: boolean; jump: boolean; skill: string; skillHeld?: string; skillMove?: THREE.Vector3; move: THREE.Vector3; dash: THREE.Vector3; sprint?: boolean }
export const DASH_CD = 3;
const DASH_T = 0.3;
const DASH_SPEED = 14;
export interface Brain { think(f: Fighter, dt: number): void }

/** Anything that can be hit: fighters and mobs. */
export interface Entity {
  id: number; kind: string; team: number; root: THREE.Group;
  hp: number; maxHp: number; radius: number; lastDamage: number; lastCrit: boolean;
  isDown(): boolean; chest(): THREE.Vector3; airborne(): boolean;
  receiveHit(attacker: Entity | null, a: Attack, power: number): string;
  update(dt: number): void;
}

export class Fighter implements Entity {
  id = 0;
  kind = "fighter";
  team = 0;
  root = new THREE.Group();
  look: Look;
  charIndex: number;
  kit: string;
  model: FighterModel;
  trail: Trail;
  brain: Brain | null = null;
  opponent: Entity | null = null;
  autoApproach = false;
  viewBias = 0;
  arenaRadius = 7;
  puppet = false;
  /** Network peer id that controls this fighter ("" = host / local). */
  owner = "";

  intent: Intent = { attack: false, block: false, jump: false, skill: "", move: new THREE.Vector3(), dash: new THREE.Vector3() };
  dashCd = 0;
  private dashT = 0;
  private dashDir = new THREE.Vector3();
  onDash: (f: Fighter) => void = () => {};

  maxHp: number; maxGuard: number; moveSpeed: number; walkSpeed: number; parryWindow: number; jumpV: number;
  attacks: Record<string, Attack>;
  poses: Record<string, Pose>;
  radius = 0.35;

  state = S.IDLE;
  stateT = 0;
  hp: number;
  guard: number;
  atk: Attack | null = null;
  atkId = "";
  atkPhase = 0;
  atkPower = 1;
  swingSerial = 0;
  lastDamage = 0;
  lastCrit = false;
  cooldowns: Record<string, number> = { z: 0, x: 0, c: 0, v: 0 };
  /** Game-controlled: purchased account V or Master CPU only. Never enabled for guests. */
  bonusSkillUnlocked = false;
  /** After a ranged combo's last hit, normal attacks rest this long (stops shot spam). */
  atkLock = 0;
  private clock = 0;
  private stunSrc = "";
  private lastStunAt = -99;
  private stunChain = 0;
  onGround = true;
  velY = 0;
  // ROXY_FROSTWING_SPELLBOOK_V3_20261108: actual 4-hit barrier and shard-hit freeze meter.
  frostShieldCharges = 0;
  frostShieldT = 0;
  frostShardStacks = 0;
  wardT = 0;
  counterT = 0;
  invulnT = 0;
  // PERFECT_DODGE_V1: a real incoming hit must land during the first 0.13s
  // of a dash, not merely while other invulnerability is active.
  perfectDodgeT = 0;
  perfectDodgeUsed = false;
  perfectDodgeCounterT = 0; // one successful melee riposte, expires after 0.95s
  /** NYX_SMOKE_BOOST: armed only once Smoke Step actually teleports. */
  nyxShadowBoostT = 0;
  parryCounterT = 0; // brief follow-up window after a successful parry
  private parryCounterTarget: Entity | null = null;
  private parryCounterPendingDepth = 0;
  parryCounterDepth = 0;
  parryRecoilT = 0; // 0.5s recoil limits offense but never causes hard stun
  private counterVisualRemote = false;

  // Survival perks.
  dmgMult = 1;
  cdMult = 1;
  critChance = 0.2;
  lifesteal = 0;

  poseName = "idle";
  poseSpeed = 14;

  onSwing: (f: Fighter) => void = () => {};
  // ZENITH_IRON_SOVEREIGN_V1_20261108 — pure game-side spear state.
  zenithSpearOut = false;
  // ZENITH_TWIN_BLADES_CATCH_CHOREO_V5_20261108: recovery is CC-only protection, never HP invulnerability.
  zenithCatchShieldT = 0;
  zenithCatchRecoilT = 0;
  zenithSpearAnchor = new THREE.Vector3();
  zenithMagnetCharges = 0;
  /** Zenith V9: 20 real seconds of Magnetic Charge; independent of spear throw state. */
  zenithMagneticChargeT = 0;
  zenithDominionRepel = false;
  onZenithRecall: (f: Fighter) => void = () => {};
  catchZenithSpear() {
    if (this.look.element !== "metal" || this.isDown()) return;
    this.zenithSpearOut = false;
    this.model.setZenithSpearHeld(true);
    this.zenithCatchShieldT = 2.0;
    this.zenithCatchRecoilT = 0.62;
    this.status.grantCcImmunity(2.0);
    this.model.zenithCatchShieldT = 2.0;
    this.model.zenithCatchRecoilT = 0.62;
    this.model.recoil = Math.max(this.model.recoil, 0.46);
    this.knock = 0;
    // A catch can break preexisting ice/jolts but never undoes damage.
    for (const cc of ["freeze", "paralyze", "slow"] as const) this.status.consume(cc);
    if (this.state === S.HITSTUN || this.state === S.STAGGER) this.setState(S.IDLE);
  }
  onKo: (f: Fighter) => void = () => {};
  /** Status effects (burn, poison, paralyze...). Damage-over-time ticks queue in `dots` for the game. */
  status = new StatusSet();
  dots: { kind: StatusKind; dmg: number; src: unknown }[] = [];
  onLanded: (f: Fighter) => void = () => {};

  private stun = 0;
  /** Public, read-only remaining hitstun for timing legitimate Combat IQ follow-ups. */
  get stunRemaining(): number {
    return (this.state === S.HITSTUN || this.state === S.STAGGER)
      ? Math.max(0, this.stun - this.stateT)
      : 0;
  }

  private leapVel = new THREE.Vector3();
  private stunPose = "hit";
  private comboNext = "l1";
  private comboTimer = 0;
  private buffered = false;
  private atkPrev = false;
  /** SWORD_AND_CYCLONE_V1: sync Kira spin and sword torso follow-through. */
  private cycloneSpin = 0;
  private bladeSwingYaw = 0;
  /** Visual-only full-body turn for Garrick Iron Tempest (host-synced). */
  private tempestSpin = 0;
  /** Visual-only spin amount for the new universal parry counter. */
  private parryCounterSpin = 0;
  // AIR_COMBAT_V1: launcher follow-up and one defensive air recovery per airtime.
  airChaseT = 0;
  private airChaseUsed = false;
  private airChaseTarget: Entity | null = null;
  private airChaseMoveT = 0;
  private airChaseDir = new THREE.Vector3();
  private airRecoverUsed = false;
  private airRecoverPrev = false;
  private airHoldT = 0;
  private airHeavyDone = false;
  // GROUNDED_AIR_SLICES_V1: one normal attack per jump. No aerial combo or slam.
  airSliceUsed = false;
  airSliceAngle = 0; // signed pitch toward the actual target, radians
  // NESA_DODGE_KIRA_AIR_3_V1: Kira may deliver three separately timed air kicks per jump.
  private kiraAirKicks = 0;
  private kiraAirBuffered = false;
  // NYX_SHADOW_COMBAT_AIR_2_V1: two separate airborne dagger hits per jump.
  private nyxAirStrikes = 0;
  private nyxAirBuffered = false;

  private airSliceQueued = false;
  // Space then Click within 0.22s still counts as a grounded anti-air chord.
  private airStartT = 99;
  private jumpPrev = false;
  private holding = false;
  private holdT = 0;
  // NESA_MOMENTUM_V3: isolated charge state; does not alter anyone else's controls.
  private nesaAirHolding = false;
  private nesaAirChargeT = 0;
  private nesaAirChargedSeconds = 0;
  private nesaChargeSeconds = 0;
  private nesaSpinYaw = 0;
  private nesaSpinT = 0;
  // NESA_FORWARD_HEART_PARRY_V_20261108: only a confirmed incoming parry unlocks giant V.
  nesaHighStrikerParried = false;
  /** Whiff refunds 40% of V cooldown and interrupts the long giant-hammer animation. */
  finishNesaStrikerWhiff(serial: number) {
    if (this.kit !== "hammer" || this.swingSerial !== serial || this.nesaHighStrikerParried) return;
    const move = this.attacks.v;
    if (move?.style !== "nesa_high_striker") return;
    // Only 60% of the ordinary cooldown remains, even if the swing was interrupted.
    this.cooldowns.v = Math.min(this.cooldowns.v ?? move.cd * this.cdMult, move.cd * this.cdMult * 0.60);
    if (this.state === S.ATTACK && this.atk?.style === "nesa_high_striker") {
      this.atk = null; this.atkId = ""; this.atkPhase = 0;
      this.holding = false; this.buffered = false;
      this.comboTimer = 0; this.comboNext = "l1";
      this.setState(S.IDLE);
    }
  }
  // NESA_HEART_SMASH_V4: three individual C charges; recovery is one charge at a time.
  nesaCCharges = 3;
  nesaCRechargeT = 0;
  private nesaCArmed = true;

  // V7 Bob mine inventory. One charge is recovered per normal mine cooldown.
  bobMineCharges = 4;
  bobMineRechargeT = 0;
  bobMineCount = 0; // authoritative trap count, maintained by Game
  // V7 Garrick C follow-up is earned by a confirmed HP hit, never on a miss.
  // BULLET_SWORDPLAY_V1: Garrick earns Resolve only from successful projectile parries/clashes.
  garrickResolve = 0;
  grantGarrickResolve() {
    if (this.kit !== "greatsword" || this.look.name !== "Garrick" || this.isDown()) return false;
    const was = this.garrickResolve;
    this.garrickResolve = Math.min(3, this.garrickResolve + 1);
    return this.garrickResolve > was;
  }
  /** Advancing means actively moving toward an opponent, not blocking or retreating. */
  private garrickIsAdvancing(toward?: Entity | null): boolean {
    if (this.kit !== "greatsword" || this.look.name !== "Garrick" ||
        this.garrickResolve < 2 || !this.onGround || this.state === S.BLOCK || this.intent.block) return false;
    const enemy = toward ?? this.opponent;
    if (!enemy || enemy.isDown()) return false;
    const aim = enemy.root.position.clone().sub(this.root.position).setY(0);
    if (aim.lengthSq() < 0.04) return false;
    const input = this.intent.move.clone().setY(0);
    if (input.lengthSq() < 0.10) {
      return this.autoApproach && this.brain !== null && this.state === S.IDLE;
    }
    return input.normalize().dot(aim.normalize()) > 0.40;
  }
  /** Resolve multiplies approach movement, never dashes, attacks, or knockback. */
  private garrickAdvanceFactor() { return this.garrickIsAdvancing() ? 1.20 : 1; }
  garrickFollowT = 0;
  garrickFollowTarget: Entity | null = null;
  private garrickRushTarget: Entity | null = null;
  private garrickRushSerial = -1;
  armGarrickFollow(target: Entity) {
    if (this.kit !== "greatsword" || target.isDown()) return;
    this.garrickFollowTarget = target;
    this.garrickFollowT = 1.65;
  }
  /** A confirmed Titan Cleave eruption launches through Fighter-owned state. */
  receiveGarrickLaunch() {
    this.velY = Math.max(this.velY, 7.0);
    this.onGround = false;
    this.ground = null;
  }
  private guardDelay = 0;
  // FIGHT_ROYALE_AI_GUARD_TIMING_PARRY_V1_20261107: expose only the real remaining regeneration wait to CPU logic.
  get guardRegenRemaining(): number { return Math.max(0, this.guardDelay); }
  /** Successful parry makes the NEXT shield raise 90% faster (0.10s to 0.01s). */
  shieldRaise = 0.10;
  nextShieldFast = false;
  /** Only ongoing multi-hit specials accumulate these parry/clash penalties. */
  comboDamageMult = 1;
  comboPauseT = 0;
  // KAIZEN_PARRY_SPIN_SLOW_REVERSE_V10: per-attack spin tempo.
  // A parry reduces Kaizen circular spin speed BY 10% (90% remains).
  // Further parries reverse direction without additional slowdown.
  kaizenSpinSpeed = 1;
  kaizenSpinDirection = 1;
  kaizenSpinTimerScale = 1; // one-shot rescaling factor for remaining timed hits
  isContinuousComboActive() {
    return this.state === S.ATTACK && !!this.atk &&
      (CONTINUOUS_STYLES.has(this.atk.style) || (this.atk.type === "phantom" && this.atk.repeat > 1));
  }
  /** Returns false for ordinary single-hit attacks (their normal stagger is preserved). */
  onComboParried(): boolean {
    if (!this.isContinuousComboActive()) return false;
    // Only actual parries of Razor Cyclone / Death Spiral slow and reverse it.
    if (this.kit === "chainblade" && this.atk &&
        (this.atk.style === "chain_razor_cyclone" || this.atk.style === "chain_death_spiral")) {
      const previous = this.kaizenSpinSpeed;
      this.kaizenSpinSpeed = 0.90;
      this.kaizenSpinTimerScale = previous / this.kaizenSpinSpeed;
      this.kaizenSpinDirection *= -1;
    }
    this.comboDamageMult = Math.max(0.35, this.comboDamageMult * 0.90);
    this.comboPauseT += 0.20;
    this.model.recoil = Math.max(this.model.recoil, 0.30);
    return true;
  }
  private knock = 0;

  armParryCounter(target: Entity | null, depth = 0) {
    // Two counter-parries are enough: prevent infinite counter-on-counter loops.
    if (depth > 2) { this.parryCounterT = 0; this.parryCounterTarget = null; return; }
    this.parryCounterT = 0.75;
    this.parryCounterTarget = target && target.team !== this.team && !target.isDown() ? target : null;
    this.parryCounterPendingDepth = depth;
  }
  hasParryCounterReady() { return this.parryCounterT > 0; }
  parryCounterReach() { return this.kit === "mage" ? 10.0 : (this.attacks.pc ?? this.attacks.l1).reach; }
  tryParryCounter(): boolean {
    // Same legal rules for a human basic-attack tap and an AI counter decision.
    if (!this.hasParryCounterReady() || !this.onGround || ![S.IDLE, S.BLOCK].includes(this.state) ||
        this.chainBindT > 0 || !!this.chainBoundBy || this.parryRecoilT > 0) return false;
    this.holding = false;
    this.startAttack("pc");
    return this.atkId === "pc" && this.state === S.ATTACK;
  }
  applyParryRecoil(seconds = 0.5) {
    // This is NOT S.STAGGER/HITSTUN: the attacker can evade, reposition or block.
    this.parryRecoilT = Math.max(this.parryRecoilT, seconds);
    this.model.recoil = Math.max(this.model.recoil, 0.85);
    this.holding = false;
    this.buffered = false;
    if (this.state === S.ATTACK && !this.isContinuousComboActive()) {
      this.finishAttack();
      this.setState(S.IDLE);
    }
  }
  private actionPoseTag() {
    if (this.counterVisualRemote || (this.atkId === "pc" && this.atk?.style === "parry_counter"))
      return `pc_${this.kit}_${this.stateT < 0.40 ? "w" : "s"}`;
    return this.poseName;
  }
  // WEIGHTED_KNOCKDOWN: physical shove follows the ACTUAL impact source,
  // not whichever enemy the AI happens to target next.
  private knockAway = new THREE.Vector3(0, 0, 1);
  private knockdownLockT = 0;
  private readonly knockdownHold = 0.82;
  private readonly wakeupDuration = 0.38;
  /** Knockdown is NOT a KO: the fighter automatically recovers. */
  knockedDown() { return this.state === S.KNOCKDOWN || this.state === S.WAKEUP; }
  /** Called from combat resolution BEFORE the hit is processed. */
  setImpactSource(from: THREE.Vector3) {
    const away = this.root.position.clone().sub(from).setY(0);
    if (away.lengthSq() > 0.0001) this.knockAway.copy(away.normalize());
  }
  /** Clash recoil strength depends on the opponent's weapon, not damage. */
  weightedClashPush(strength: number) {
    if (this.zenithCatchShieldT > 0) return;
    if (!this.stage && !this.meteorFistArmor && !this.hammerWeightArmor && !this.knockedDown())
      this.knock = this.state === S.HITSTUN && this.stunPose === "clash"
        ? Math.min(8, strength) : Math.max(this.knock, Math.min(8, strength));
  }
  private beginKnockdown() {
    if (this.zenithCatchShieldT > 0) return;
    // No knockdown during airborne juggles, binds, or armored specials.
    this.knockdownLockT = 2.3;
    this.holding = false; this.buffered = false;
    this.atk = null; this.atkId = ""; this.atkPhase = 0;
    this.dashT = 0; this.perfectDodgeT = 0;
    this.airChaseT = 0; this.airChaseMoveT = 0;
    this.comboPauseT = 0;
    this.setState(S.KNOCKDOWN);
    this.model.fall();
    this.model.recoil = Math.max(this.model.recoil, 0.6);
  }
  private netPos = new THREE.Vector3();
  private netRot = 0;

  // Platform-fighter state.
  stage: Stage | null = null;
  pct = 0;
  stocks = STOCKS;
  /** Off screen after a blast-zone KO, waiting to respawn. */
  out = false;
  vx = 0;
  facing = 1;
  lane = 0;
  onBlast: (f: Fighter) => void = () => {};
  private airJumps = 1;
  /** Arena double jump (wind kit): jumps used in the current air time. */
  private airJump = 0;
  /** Time left in the double-jump wind-ride pose. */
  private airJumpT = 0;
  onAirJump: (f: Fighter) => void = () => {};
  /** Bomber: a powder keg is out on the field (the skill becomes its trigger). */
  barrelOut = false;
  barrelPos = new THREE.Vector3();
  /** Pressing the keg's skill while it is out asks the arena to detonate it. */
  onTrigger: (f: Fighter) => void = () => {};
  onSnowCommand: (f: Fighter, key: string) => boolean = () => false;
  /** Blood Hunter: steering recast and 0.30s feint window. */
  sickleOut = false;
  bloodFeintT = 0;
  clashMomentum = 0; // KAIZEN_BIND_ZAREK_COUNTER_V4: unlimited round clash count (legacy network field name).
  chainFuryT = 0; // legacy field retained for existing snapshots/weapon code.
  // KAIZEN_DIRECTIONAL_V3: direction is relative to facing at skill-press, never hard-coded WASD.
  chainSkillDir: "forward" | "backward" | "left" | "right" | "neutral" = "neutral";
  chainHookTarget: Entity | null = null;
  chainHookT = 0;
  /** Immobilizes both fighters until a new forward/back input or the 4 second timeout. */
  chainBindTarget: Fighter | null = null;
  chainBoundBy: Fighter | null = null;
  chainBindT = 0;
  chainBindKind: "x" | "v" | "" = "";
  chainChoiceArmed = false;
  // KAIZEN_BIND_FOLLOWUP_V7: after selecting Z/X, both remain bound until the action finishes.
  chainBindFinishT = 0;
  chainResolveDirection: "forward" | "backward" | "" = "";
  // KAIZEN_SERPENT_SLAM_V10: authoritative animation begins at the actual victim position.
  chainBindFinishDuration = 0;
  chainBindStartPos = new THREE.Vector3();
  onChainBindResolve: (f: Fighter, dir: "forward" | "backward", kind: "x" | "v") => void = () => {};
  bloodlust = 0;
  bloodFrenzyT = 0;
  /** Blood Festival: stun-immune, but damageable and all skills disabled until expiration. */
  bloodFestivalT = 0;
  onSickleRecast: (f: Fighter) => void = () => {};
  /** Super armor only while Rook is performing Meteor Fist (wind-up, leap, landing recovery). */
  private get meteorFistArmor(): boolean {
    return this.kit === "knuckles" && this.state === S.ATTACK && this.atk?.name === "Meteor Fist";
  }

  private get hammerWeightArmor(): boolean {
    if (this.kit !== "hammer" || this.state !== S.ATTACK || !this.atk) return false;
    // Upsie Daisie: immune to stun/knockback from the FIRST frame of its cast.
    // Every other hammer attack is vulnerable during its entire wind-up.
    return this.atk.name === "Upsie Daisie" || this.atkPhase >= 1;
  }

  private ground: Plat | null = null;
  private dropT = 0;
  private respawnT = 0;
  private upPrev = false;
  private downPrev = false;
  private knockFrom = 0;

  /** Damage multiplier from Berserk, while rageT > 0. */
  rageT = 0;
  /** ASTER_EMBER_LATEST_20261106: 10-second empowered sword/shield form. */
  judgmentT = 0;

  /** Core skills never remap. V is independent, requiring a match-scoped unlock. */
  constructor(look: Look, charIndex: number, _loadout: string[] = DEFAULT_LOADOUT,
    emblem?: { id: string; level: number }, bonusSkillUnlocked = false) {
    this.bonusSkillUnlocked = bonusSkillUnlocked;
    this.look = look;
    this.charIndex = charIndex;
    this.kit = look.kit;
    const st = Kits.STATS[this.kit];
    this.maxHp = st.hp; this.maxGuard = st.guard; this.moveSpeed = st.move; this.walkSpeed = st.walk;
    // Aster only: +12% HP (2500 -> 2800), +25% shield guard (100 -> 125).
    if (this.kit === "knight" && look.element === "light") {
      this.maxHp *= 1.12;
      this.maxGuard *= 1.25;
    }
    // FIGHT_ROYALE_GUARD_CAPACITY_AVG_2X_1P5X_V3
    // Apply relative to ORIGINAL kit guard, not the older Aster +25% adjustment.
    // Keep emblem effects below so they scale the new base guard normally.
    if (look.name === "Aster" || look.name === "Vesper") this.maxGuard = st.guard * 2.0;
    else if (look.name === "Garrick") this.maxGuard = st.guard * 1.5;
    this.parryWindow = st.parry; this.jumpV = st.jump;
    this.hp = this.maxHp;
    this.guard = this.maxGuard;
    this.attacks = Kits.attacks(this.kit, look.element);
    // Keep Kits.attacks' original Z, X, C and V definitions, including air variants.
    // Previously saved 3-of-4 loadouts are ignored rather than remapping V to another key.
    if (emblem) {
      const b = emblemBonus(emblem.id, emblem.level);
      this.maxHp *= 1 + b.hp;
      this.maxGuard *= 1 + b.guard;
      this.dmgMult *= 1 + b.dmg;
      this.critChance += b.crit;
      this.cdMult *= 1 - b.cd;
      this.moveSpeed *= 1 + b.speed;
    }
    this.poses = Kits.poses(this.kit, this.look.element);
    // Extra poses use the same procedural/VRM rig, including remote fighters.
    this.buildDirectionalAirPoses();
    this.attacks.air_l1 = { ...this.attacks.air_l1, next: "", lunge: 0,
      knock: Math.min(this.attacks.air_l1.knock, 0.8),
      heavy: false, stagger: false, recover: Math.max(this.attacks.air_l1.recover, 0.30) };
    // NESA_DODGE_KIRA_AIR_3_V1: Kira's three aerial kicks are standard melee hits:
    // the shield blocks them and overlapping attacks clash; perfect parry does not.
    if (this.kit === "kicks") {
      for (let i = 1; i <= 3; i++) {
        const key = `air_l${i}`;
        const original = this.attacks[key];
        this.attacks[key] = { ...original, type: "melee", no_parry: true,
          wind: 0.075, active: 0.085, recover: i === 3 ? 0.18 : 0.105,
          reach: 2.0 + 0.08 * (i - 1), lunge: 0,
          knock: i === 3 ? 2.1 : 0.8, heavy: false, stagger: false, next: "" };
      }
    }
    if (this.kit === "assassin") {
      // Two real aerial melee swings, each with separate block, parry, clash and hit tests.
      this.attacks.air_l1 = { ...this.attacks.air_l1,
        name: "Falling Fang", type: "melee", wind: 0.080, active: 0.095, recover: 0.13,
        dmg: 28, guard: 12, reach: 2.04, lunge: 0,
        knock: 0.75, heavy: false, stagger: false, next: "" };
      this.attacks.air_l2 = { ...this.attacks.air_l2,
        name: "Shadow Cross", type: "melee", wind: 0.095, active: 0.105, recover: 0.23,
        dmg: 38, guard: 16, reach: 2.17, lunge: 0,
        knock: 2.2, stun: 0.30, heavy: false, stagger: false, next: "" };
    }
    this.root.rotation.order = "YXZ";
    this.model = new FighterModel(look);
    this.root.add(this.model);
    this.trail = new Trail(this.model.bladeBase, this.model.bladeTip,
      this.kit === "hammer" ? "#ff53b9" : look.glow,
      this.kit === "hammer" ? 0.25 : 0.16);
  }

  // Use each kit's own windup and strike as a starting point, keeping weapon grip.
  // A downward slash visibly starts above the head and cuts toward the feet.
  private buildDirectionalAirPoses() {
    const source = (key: string) => this.poses[key] ?? this.poses.jump ?? this.poses.idle;
    const wind = source(this.attacks.air_l1.pose_w);
    const strike = source(this.attacks.air_l1.pose_s);
    const v3 = (v: [number, number, number]): [number, number, number] =>
      [v[0], v[1], v[2]];
    const copy = (p: Pose): Pose => ({
      ...p, torso: v3(p.torso), head: v3(p.head),
      arm_r: v3(p.arm_r), hand_r: v3(p.hand_r),
      arm_l: v3(p.arm_l), hand_l: v3(p.hand_l),
      leg_l: v3(p.leg_l), leg_r: v3(p.leg_r),
      knee: p.knee ? [p.knee[0], p.knee[1]] : undefined,
    });
    const ranged = this.kit === "bow" || this.kit === "mage";
    const kicks = this.kit === "kicks";
    for (const [direction, pitch] of [["down", -1], ["level", 0], ["up", 1]] as const) {
      const w = copy(wind), a = copy(strike);
      if (pitch < 0) {
        w.torso[0] -= 0.18; a.torso[0] += 0.30;
        w.head[0] += 0.12; a.head[0] += 0.19;
        if (kicks) {
          w.leg_r[0] += 0.24; a.leg_r[0] -= 1.30;
          w.leg_l[0] += 0.20; a.leg_l[0] += 0.32;
        } else if (!ranged) {
          w.arm_r[0] = Math.min(w.arm_r[0], -1.85);
          a.arm_r[0] = Math.max(a.arm_r[0], 0.37);
          w.arm_l[0] = Math.min(w.arm_l[0], -0.95);
          a.arm_l[0] += 0.27;
        }
      } else if (pitch > 0) {
        w.torso[0] += 0.09; a.torso[0] -= 0.23;
        a.head[0] -= 0.16;
        if (kicks) {
          w.leg_r[0] += 0.24; a.leg_r[0] -= 1.55;
        } else if (!ranged) {
          w.arm_r[0] = Math.max(w.arm_r[0], -0.33);
          a.arm_r[0] = Math.min(a.arm_r[0], -1.65);
          a.arm_l[0] -= 0.24;
        }
      } else {
        w.torso[1] += 0.13; a.torso[1] -= 0.27;
        if (kicks) a.leg_r[0] -= 0.75;
      }
      w.leg_l[0] -= 0.28; w.leg_r[0] += 0.19;
      a.leg_l[0] -= 0.20; a.leg_r[0] += 0.25;
      this.poses[`air_slice_${direction}_w`] = w;
      this.poses[`air_slice_${direction}_s`] = a;
      if (this.kit === "kicks") {
        // Three recognizable aerial kick beats (right, left, turning heel).
        for (let n = 1; n <= 3; n++) {
          const kw = copy(w), ks = copy(a);
          if (n === 2) {
            // Opposite leg initiates the second kick, with slight waist counterturn.
            const t0 = kw.leg_r; kw.leg_r = kw.leg_l; kw.leg_l = t0;
            const t1 = ks.leg_r; ks.leg_r = ks.leg_l; ks.leg_l = t1;
            kw.torso[1] -= 0.22; ks.torso[1] += 0.24;
          } else if (n === 3) {
            kw.torso[1] += 0.35; ks.torso[1] -= 0.42;
            kw.leg_r[0] -= 0.38; ks.leg_r[0] -= 0.55;
            kw.leg_l[0] += 0.30; ks.leg_l[0] += 0.25;
          }
          this.poses[`kira_air_${n}_${direction}_w`] = kw;
          this.poses[`kira_air_${n}_${direction}_s`] = ks;
        }
      }
      if (this.kit === "assassin") {
        // Dagger one sweeps across with the right hand, dagger two reverses with the left.
        // Both poses are generated for up/level/down aim; they also work for VRM avatars.
        for (let n = 1; n <= 2; n++) {
          const nw = copy(w), ns = copy(a);
          nw.torso[0] += 0.02; ns.torso[0] += 0.10;
          nw.hips_y -= 0.015;
          nw.leg_l[0] -= 0.22; nw.leg_r[0] -= 0.16;
          ns.leg_l[0] += 0.11; ns.leg_r[0] -= 0.15;
          if (n === 1) {
            nw.torso[1] -= 0.38; ns.torso[1] += 0.55;
            nw.arm_r[0] = -0.76; nw.arm_r[1] = -0.98;
            nw.hand_r[0] = 1.05;
            ns.arm_r[0] = -1.46; ns.arm_r[1] = 1.11;
            ns.hand_r[0] = 1.3;
            nw.arm_l[0] = -1.10; ns.arm_l[0] = -1.18;
          } else {
            nw.torso[1] += 0.42; ns.torso[1] -= 0.61;
            nw.arm_l[0] = -0.73; nw.arm_l[1] = 1.05;
            nw.hand_l[0] = 1.11;
            ns.arm_l[0] = -1.57; ns.arm_l[1] = -1.16;
            ns.hand_l[0] = 1.36;
            nw.arm_r[0] = -1.03; ns.arm_r[0] = -1.14;
          }
          this.poses[`nyx_air_${n}_${direction}_w`] = nw;
          this.poses[`nyx_air_${n}_${direction}_s`] = ns;
        }
      }
    }
  }

  /** Lock aim at contact time, not the earlier button press. */
  private airAimAtOpponent(): number {
    const opponent = this.opponent;
    if (!opponent || opponent.isDown()) return 0;
    const delta = opponent.chest().sub(this.chest());
    const horizontal = Math.hypot(delta.x, delta.z);
    if (horizontal > 3.0) return 0;
    return THREE.MathUtils.clamp(Math.atan2(delta.y, Math.max(0.45, horizontal)), -1.20, 0.90);
  }

  private nesaReleaseAirStrike() {
    if (!this.nesaAirHolding || this.airSliceUsed || this.state === S.KO) return;
    this.nesaAirHolding = false;
    this.nesaAirChargedSeconds = Math.max(0.05, Math.min(this.nesaAirChargeT, 0.88));
    this.nesaAirChargeT = 0;
    this.tryAirSlice();
  }

  private tryAirSlice() {
    if (this.onGround || this.airSliceUsed || this.atkLock > 0 ||
        (this.state !== S.IDLE && this.state !== S.BLOCK)) return;
    // NESA_DODGE_KIRA_AIR_3_V1: 3 taps / connected kicks for Kira, one for others.
    if (this.kit === "kicks") this.kiraAirKicks = Math.min(3, this.kiraAirKicks + 1);
    if (this.kit === "assassin") this.nyxAirStrikes = Math.min(2, this.nyxAirStrikes + 1);
    this.airSliceUsed = this.kit === "kicks" ? this.kiraAirKicks >= 3 :
      this.kit === "assassin" ? this.nyxAirStrikes >= 2 : true;
    this.kiraAirBuffered = false;
    this.nyxAirBuffered = false;
    this.airSliceQueued = false;
    this.airSliceAngle = this.airAimAtOpponent();
    this.holding = false;
    this.startAttack(this.kit === "kicks" ? `air_l${this.kiraAirKicks}` :
      this.kit === "assassin" ? `air_l${this.nyxAirStrikes}` : "air_l1");
  }

  isDown() { return this.state === S.KO; }
  chest() { return this.root.position.clone().add(new THREE.Vector3(0, 1.1, 0)); }
  airborne() { return this.stage ? !this.onGround : !this.onGround && this.root.position.y > 0.7; }
  /** Stick up / down (side view: the camera looks down -Z, so "up" is -Z on the stick). */
  private up() { return -this.intent.move.z > 0.5; }
  private down() { return -this.intent.move.z < -0.5; }

  update(dt: number) {
    if (this.puppet) { this.updatePuppet(dt); return; }
    const it = this.intent;
    it.attack = false; it.block = false; it.jump = false; it.skill = ""; it.skillHeld = ""; it.sprint = false;
    it.skillMove?.set(0, 0, 0); it.move.set(0, 0, 0); it.dash.set(0, 0, 0);
    if (this.out) { this.waitRespawn(dt); return; }
    if (this.brain && this.state !== S.KO && this.state !== S.WIN) this.brain.think(this, dt);
    // AIR_COMBAT_V1: Right Click while hit-stunned in air = one escape per airtime.
    this.tryAirRecovery();
    // Ground and airborne blocks both work; perfect parry still uses its normal timing.
    // Escaping hitstun is handled separately, once per airtime.
    // A successful parry pauses a persistent combo for exactly 0.20 seconds;
    // its delayed arena hits are shifted by the same amount in Game.
    const advancing = this.state === S.ATTACK && this.comboPauseT > 0
      ? Math.max(0, dt - this.comboPauseT) : dt;
    this.comboPauseT = Math.max(0, this.comboPauseT - dt);
    // Keep animation pose timing aligned with the slowed damage pulse schedule.
    // Only the CURRENT circular chainblade skill is slowed, never other attacks.
    const slowedKaizenSpin = this.kit === "chainblade" && this.state === S.ATTACK &&
      (this.atk?.style === "chain_razor_cyclone" || this.atk?.style === "chain_death_spiral");
    // Roxy Freeze V4: Slow changes combat clocks, not cooldown timers or hitstun recovery.
    const frostActionScale = (this.state === S.ATTACK || this.state === S.CHARGE)
      ? this.status.actionSpeedMult() : 1;
    this.stateT += advancing * (slowedKaizenSpin ? this.kaizenSpinSpeed : 1) * frostActionScale;
    for (const k in this.cooldowns) this.cooldowns[k] = Math.max(this.cooldowns[k] - dt, 0);
    if (this.kit === "hammer") {
      // NESA_HEART_SMASH_V4: one charge returns every 7.5 seconds, max three.
      if (this.nesaCCharges < 3) {
        this.nesaCRechargeT = Math.max(0, this.nesaCRechargeT - dt);
        if (this.nesaCRechargeT <= 0) {
          this.nesaCCharges = Math.min(3, this.nesaCCharges + 1);
          this.nesaCRechargeT = this.nesaCCharges < 3 ? 7.5 * this.cdMult : 0;
        }
      } else this.nesaCRechargeT = 0;
      // NESA_V5_LOADOUT_AIR_SPIN_UPRIGHT: charges belong to Pink Heart Smash,
      // wherever the loadout equips it (Z / X / C), never to the C key itself.
      const heartSlot = ["z", "x", "c"].find(k => this.attacks[k]?.style === "nesa_heart_slam");
      if (heartSlot) this.cooldowns[heartSlot] = this.nesaCCharges > 0 ? 0 : this.nesaCRechargeT;
      if (!this.intent.skill || this.attacks[this.intent.skill]?.style !== "nesa_heart_slam") this.nesaCArmed = true;
    }

    this.atkLock = Math.max(this.atkLock - dt, 0);
    // Bob ammo recharges sequentially, even while two mines remain deployed.
    if (this.kit === "bomb") {
      const mineSlot = ["z", "x", "c"].find(k => this.attacks[k]?.type === "mine");
      if (mineSlot) {
        const period = Math.max(0.2, this.attacks[mineSlot].cd * this.cdMult);
        if (this.bobMineCharges < 4) {
          this.bobMineRechargeT -= dt;
          if (this.bobMineRechargeT <= 0) {
            this.bobMineCharges = Math.min(4, this.bobMineCharges + 1);
            this.bobMineRechargeT = this.bobMineCharges === 4 ? 0 : period;
          }
        }
        this.cooldowns[mineSlot] = this.bobMineCharges > 0 ? 0 : Math.max(0, this.bobMineRechargeT);
      }
    }
    this.garrickFollowT = Math.max(0, this.garrickFollowT - dt);
    if (this.garrickFollowT <= 0 || this.garrickFollowTarget?.isDown()) {
      this.garrickFollowTarget = null;
      this.garrickFollowT = 0;
    }
    if (this.look.element === "metal")
      this.zenithMagneticChargeT = Math.max(0, this.zenithMagneticChargeT - dt);
    this.zenithCatchShieldT = Math.max(0, this.zenithCatchShieldT - dt);
    this.zenithCatchRecoilT = Math.max(0, this.zenithCatchRecoilT - dt);
    if (this.look.element === "metal") {
      this.model.zenithCatchShieldT = this.zenithCatchShieldT;
      this.model.zenithCatchRecoilT = this.zenithCatchRecoilT;
      if (this.zenithCatchRecoilT > 0) {
        this.intent.attack = false;
        this.intent.skill = "";
        this.intent.skillHeld = "";
        this.intent.move.set(0, 0, 0);
        this.intent.dash.set(0, 0, 0);
      }
    }
    this.clock += dt;
    this.knockdownLockT = Math.max(0, this.knockdownLockT - dt);
    this.dashCd = Math.max(this.dashCd - dt, 0);
    this.dashT = Math.max(this.dashT - dt, 0);
    this.readDash();
    this.wardT = Math.max(this.wardT - dt, 0);
    this.frostShieldT = Math.max(0, this.frostShieldT - dt);
    if (this.frostShieldT === 0) this.frostShieldCharges = 0;
    this.rageT = Math.max(this.rageT - dt, 0);
    if (this.judgmentT > 0) {
      this.judgmentT = Math.max(0, this.judgmentT - dt);
      // Judgment lightning is harmless; the transformation itself costs 1.2% HP/s.
      this.hp = Math.max(1, this.hp - this.maxHp * 0.012 * dt);
    }
    this.chainFuryT = Math.max(this.chainFuryT - dt, 0);
    this.chainHookT = Math.max(0, this.chainHookT - dt);
    if (this.chainHookT === 0) this.chainHookTarget = null;
    this.counterT = Math.max(this.counterT - dt, 0);
    this.bloodFeintT = Math.max(this.bloodFeintT - dt, 0);
    // VEYR_BLOODLUST_CARRION_V7: drain the Frenzy meter evenly rather than snapping from 100 to 0.
    const frenzyWasActive = this.bloodFrenzyT > 0;
    this.bloodFrenzyT = Math.max(this.bloodFrenzyT - dt, 0);
    if (this.kit === "sickle" && frenzyWasActive)
      this.bloodlust = Math.min(100, Math.max(0, 100 * this.bloodFrenzyT / 5));
    this.bloodFestivalT = Math.max(this.bloodFestivalT - dt, 0);
    this.invulnT = Math.max(this.invulnT - dt, 0);
    this.perfectDodgeT = Math.max(0, this.perfectDodgeT - dt);
    this.perfectDodgeCounterT = Math.max(0, this.perfectDodgeCounterT - dt);
    this.nyxShadowBoostT = Math.max(0, this.nyxShadowBoostT - dt);
    this.parryCounterT = Math.max(0, this.parryCounterT - dt);
    this.parryRecoilT = Math.max(0, this.parryRecoilT - dt);
    if (this.parryRecoilT > 0) this.model.recoil = Math.max(this.model.recoil, 0.23 + 0.35 * this.parryRecoilT);
    this.airJumpT = Math.max(this.airJumpT - dt, 0);
    this.airChaseT = Math.max(this.airChaseT - dt, 0);
    this.airChaseMoveT = Math.max(this.airChaseMoveT - dt, 0);
    this.airStartT = Math.min(99, this.airStartT + dt);
    this.tickStatus(dt);
    if (this.chainBindTarget && (this.chainBindTarget.isDown() || this.state === S.KO))
      this.releaseChainBind();
    // KAIZEN_PREDATOR_HOOK_V9: X bind allows Kaizen to walk, but locks other attacks/skills.
    // X recast pulls the victim toward Kaizen; Serpent Bind (V) keeps Z/X throws.
    if (this.chainBindTarget && this.chainBindT > 0) {
      const hook = this.chainBindKind === "x";
      if (this.chainBindFinishT > 0) {
        this.intent.skill = "";
        this.chainBindFinishT = Math.max(0, this.chainBindFinishT - dt);
        this.chainBindT = this.chainBindFinishT;
        if (this.chainBindFinishT === 0) this.releaseChainBind();
      } else {
        this.chainBindT = Math.max(0, this.chainBindT - dt);
        const choice = this.intent.skill;
        if (!choice) this.chainChoiceArmed = true;
        else if (this.chainChoiceArmed && (hook ? choice === "x" : choice === "z" || choice === "x")) {
          const direction = hook || choice === "x" ? "backward" : "forward";
          const kind = this.chainBindKind as "x" | "v";
          this.chainChoiceArmed = false;
          this.chainResolveDirection = direction;
          // Serpent Bind: a full reel-in, lift, three-impact throw sequence.
          // X hook is still a short single yank, with free movement while bound.
          this.chainBindFinishT = hook ? 0.40 : 1.85;
          this.chainBindFinishDuration = this.chainBindFinishT;
          this.chainBindStartPos.copy(this.chainBindTarget.root.position);
          this.chainBindT = this.chainBindFinishT;
          this.intent.skill = ""; // recast is consumed, NEVER cast another ordinary X
          this.onChainBindResolve(this, direction, kind);
        }
        if (this.chainBindT === 0) this.releaseChainBind();
      }
    }
    const hookOwner = this.chainBindT > 0 && this.chainBindTarget !== null && this.chainBindKind === "x";
    const boundOwner = this.chainBoundBy && this.chainBoundBy.chainBindT > 0 ? this.chainBoundBy : null;
    if (hookOwner) {
      // Kaizen walks normally while the target is tethered, but can't cast, attack, dodge,
      // jump or parry for free. The model continues to draw a chain to the victim.
      this.intent.skill = ""; this.intent.attack = false;
      this.intent.block = false; this.intent.jump = false;
      this.vx = 0; this.knock = 0; this.dashT = 0;
      if (this.state !== S.IDLE) this.setState(S.IDLE);
      if (this.stage) { this.movePlat(dt); this.verticalPlat(dt); }
      else { this.move(dt); this.vertical(dt); }
      this.poseName = "cbh_s";
      this.model.chainPose = "cbh_s";
      this.model.chainBindTargetWorld = this.chainBindTarget!.chest();
      this.model.blend(this.poses[this.poseName] ?? this.poses.idle, dt, 13);
      this.trail.update(dt);
      return;
    }
    // The bound opponent stays still until the recast. During the 0.4s pull, the
    // host smoothly draws them toward Kaizen (never moves Kaizen automatically).
    if (boundOwner && boundOwner.chainBindKind === "x") {
      this.vx = 0; this.velY = 0; this.knock = 0; this.dashT = 0;
      this.airChaseMoveT = 0;
      if (boundOwner.chainBindFinishT > 0) {
        const toward = boundOwner.root.position.clone().sub(this.root.position).setY(0);
        const dist = toward.length();
        const amount = Math.min(Math.max(0, dist - 1.25), 17 * dt);
        if (amount > 0.001) {
          this.root.position.addScaledVector(toward.multiplyScalar(1 / dist), amount);
          if (this.stage) {
            this.root.position.x = THREE.MathUtils.clamp(this.root.position.x,
              this.stage.blast.l + 1, this.stage.blast.r - 1);
          } else {
            const radial = Math.hypot(this.root.position.x, this.root.position.z);
            if (radial > this.arenaRadius) {
              this.root.position.x *= this.arenaRadius / radial;
              this.root.position.z *= this.arenaRadius / radial;
            }
          }
        }
      }
      this.model.walk = 0; this.trail.emitting = false;
      this.poseName = "hit";
      this.model.blend(this.poses.hit ?? this.poses.idle, dt, 13);
      this.trail.update(dt);
      return;
    }
    // KAIZEN_SERPENT_SLAM_V10: Keep the chain locked for the ENTIRE animation,
    // drive the victim through alternating slams, and freeze all regular controls.
    if (this.chainBindT > 0 || boundOwner) {
      this.vx = 0; this.velY = 0; this.knock = 0; this.dashT = 0;
      this.airChaseMoveT = 0; this.model.walk = 0; this.trail.emitting = false;
      this.intent.attack = false; this.intent.skill = ""; this.intent.jump = false;
      this.model.chainBindTargetWorld = this.chainBindTarget?.chest() ?? null;
      if (boundOwner && boundOwner.chainBindKind === "v" && boundOwner.chainBindFinishT > 0) {
        this.animateSerpentBound(boundOwner, dt);
      } else if (this.chainBindTarget && this.chainBindKind === "v" && this.chainBindFinishT > 0) {
        const t = this.chainBindFinishDuration - this.chainBindFinishT;
        this.poseName = t < 0.26 ? "cbh_s" : t < 0.59 ? "cbv_s" :
          t < 0.95 ? "cbx1_s" : t < 1.27 ? "cbx2_s" : "cbx3_s";
        this.model.chainPose = this.poseName;
        this.model.blend(this.poses[this.poseName] ?? this.poses.idle, dt, 34);
      } else {
        this.poseName = this.kit === "chainblade" ? "cbv_s" : "hit";
        this.model.chainPose = this.poseName;
        this.model.blend(this.poses[this.poseName] ?? this.poses.idle, dt, 16);
      }
      this.trail.update(dt);
      return;
    }
    this.model.chainBindTargetWorld = null;
    this.readAttack(dt);
    this.readJump();
    this.readSkill();

    switch (this.state) {
      case S.IDLE:
        this.comboTimer -= dt;
        if (this.comboTimer <= 0) this.comboNext = "l1";
        if (it.block) this.setState(S.BLOCK);
        break;
      case S.ATTACK: this.attackStep(); break;
      case S.CHARGE:
        if (it.block) { this.holding = false; this.setState(S.BLOCK); }
        else if (this.stateT >= (this.kit === "hammer" ? 1.53 : CHARGE_MAX)) {
          this.holding = false; this.startAttack("heavy");
        }
        break;
      case S.BLOCK: if (!it.block) this.setState(S.IDLE); break;
      case S.HITSTUN:
      case S.STAGGER: if (this.stateT >= this.stun) this.setState(S.IDLE); break;
      case S.KNOCKDOWN:
        if (this.stateT >= this.knockdownHold) this.setState(S.WAKEUP);
        break;
      case S.WAKEUP:
        if (this.stateT >= this.wakeupDuration) {
          this.model.standUp();
          this.invulnT = Math.max(this.invulnT, 0.24);
          this.setState(S.IDLE);
        }
        break;
    }

    if (this.stage) { this.movePlat(dt); this.verticalPlat(dt); }
    else { this.move(dt); this.vertical(dt); }
    // Count down the two-second damage-free timer even while defending.
    // Holding block still prevents actual guard regeneration, just as before.
    this.guardDelay = Math.max(0, this.guardDelay - dt);
    if (this.state !== S.BLOCK && this.guardDelay <= 0) {
      // KAIZEN_GUARD_CLASH_V8: Kaizen regenerates guard at half the usual rate.
      const guardRegen = this.kit === "chainblade" ? GUARD_REGEN * 0.5 : GUARD_REGEN;
      this.guard = Math.min(this.guard + guardRegen * dt, this.maxGuard);
    }
    const a = this.atk;
    this.trail.emitting = this.state === S.ATTACK && !!a &&
      (a.type === "melee" || a.style === "iron_tempest" || this.kit === "hammer") &&
      (this.atkPhase === 1 || (this.atkPhase === 0 && this.stateT > a.wind * 0.6) || (this.atkPhase === 2 && this.stateT < a.wind + a.active + 0.05));
    this.model.setBarrier(this.state === S.BLOCK && this.kit === "mage");
    this.model.setJudgment(this.kit === "knight" && this.look.element === "light" && this.judgmentT > 0);
    this.model.combat = [S.ATTACK, S.CHARGE, S.BLOCK, S.HITSTUN, S.STAGGER].includes(this.state);
    this.model.hurt = this.state === S.HITSTUN || this.state === S.STAGGER;
    this.model.charge = this.kit === "hammer" && this.nesaAirHolding
      ? Math.min(1, this.nesaAirChargeT / 0.88)
      : this.state === S.CHARGE ? Math.min(this.stateT / (this.kit === "hammer" ? 1.53 : CHARGE_MAX), 1)
      : Math.max(this.model.charge - dt * 4, 0);
    // Iron Tempest: one full turn over the attack's active window.
    // Model-only rotation preserves the player-facing direction and collision tests.
    const tempestActive = this.kit === "greatsword" && this.state === S.ATTACK && this.atk?.style === "iron_tempest";
    const tempestPhase = tempestActive ? Math.max(0, Math.min(1, (this.stateT - this.atk!.wind) / this.atk!.active)) : 0;
    this.tempestSpin = tempestActive ? Math.PI * 2 * (tempestPhase * tempestPhase * (3 - 2 * tempestPhase)) : 0;
    // SWORD_AND_CYCLONE_V1: Kira turns her ENTIRE body while the feet alternate.
    const cycloneActive = this.kit === "kicks" && this.state === S.ATTACK && this.atk?.style === "cyclone_kick_v2";
    const cyclonePhase = cycloneActive ? Math.max(0, Math.min(1, (this.stateT - this.atk!.wind) / this.atk!.active)) : 0;
    this.cycloneSpin = cycloneActive ? Math.PI * 4 * (cyclonePhase * cyclonePhase * (3 - 2 * cyclonePhase)) : 0;
    const parryCounterActive = this.state === S.ATTACK && this.atkId === "pc" && this.atk?.style === "parry_counter";
    const parryCounterPhase = parryCounterActive ? Math.max(0, Math.min(1, this.stateT / Math.max(this.atk?.wind ?? 0.4, 0.01))) : 0;
    this.parryCounterSpin = parryCounterActive ? Math.PI * 2 * (parryCounterPhase * parryCounterPhase * (3 - 2 * parryCounterPhase)) : 0;
    this.model.parryCounterSpin = this.parryCounterSpin;
    // One-handed Aster and two-handed Garrick lead sword strikes with their torsos.
    // No world-facing change: hit detection and shielding remain authoritative.
    const bladeActive = this.state === S.ATTACK && this.atk?.type === "melee" &&
      ((this.kit === "greatsword") || (this.kit === "hammer") || (this.kit === "glaive") || (this.kit === "knight" && this.look.element === "light"));
    if (bladeActive) {
      const a = this.atk!;
      const progress = Math.max(0, Math.min(1, this.stateT / Math.max(a.wind + a.active, 0.01)));
      const turn = progress * progress * (3 - 2 * progress);
      const direction = this.atkId === "l2" ? -1 : 1;
      const recoveryT = Math.max(0, Math.min(1, (this.stateT - a.wind - a.active) / Math.max(0.01, a.recover)));
      const settle = 1 - recoveryT * recoveryT * (3 - 2 * recoveryT);
      this.bladeSwingYaw = direction * ((this.kit === "greatsword" || this.kit === "hammer") ? 0.48 : this.kit === "glaive" ? (this.atkId === "l4" ? 0.44 : 0.29) : 0.27) * (1 - 2 * turn) * settle;
    } else this.bladeSwingYaw = 0;
    if (this.kit === "hammer") {
      const attack = this.state === S.ATTACK ? this.atk : null;
      if ((attack?.style === "nesa_spin" || attack?.style === "nesa_air_spin") && this.stateT >= attack.wind &&
          this.stateT <= attack.wind + attack.active) {
        const t = Math.max(0, (this.stateT - attack.wind) / attack.active);
        const turns = Math.max(1, Math.round(attack.active / 0.27));
        this.nesaSpinYaw = t * turns * Math.PI * 2;
      } else this.nesaSpinYaw = 0;
      this.model.nesaSpinHorizontal = (attack?.style === "nesa_spin" || attack?.style === "nesa_air_spin" || attack?.style === "parry_counter") ?
        THREE.MathUtils.clamp(this.stateT / Math.max(0.01, attack.wind), 0, 1) : 0;
      this.model.nesaHammerScale = attack?.style === "nesa_high_striker" &&
        this.nesaHighStrikerParried &&
        this.stateT >= attack.wind + 0.24 && this.stateT < attack.wind + attack.active + 0.12
        ? 4 : 1;
    } else { this.nesaSpinYaw = 0; this.model.nesaSpinHorizontal = 0; }
    this.model.rotation.y = this.viewBias + this.tempestSpin + this.cycloneSpin + this.bladeSwingYaw + this.nesaSpinYaw + this.parryCounterSpin;
    this.computePose();
    this.model.bloodFestivalT = this.kit === "sickle" ? this.bloodFestivalT : 0;
    this.model.chainFuryT = this.kit === "chainblade" ? this.chainFuryT : 0;
    this.model.kaizenSpinSpeed = this.kaizenSpinSpeed;
    this.model.kaizenSpinDirection = this.kaizenSpinDirection;
    this.model.kaizenSpinActive = this.kit === "chainblade" && this.state === S.ATTACK &&
      this.kaizenSpinSpeed < 1;
    this.model.chainPose = this.kit === "chainblade"
      ? (this.state === S.WIN && this.stateT >= 0.55 && this.stateT <= 2.30 ? "cbz_w" : this.poseName)
      : "idle";
    this.model.chainExtended = this.kit === "chainblade" && (this.chainFuryT > 0 ||
      ["cbz_w", "cbz_s", "cbx_w", "cbx1_s", "cbx2_s", "cbx3_s", "cbh_w", "cbh_s", "cbv_w", "cbv_s"].includes(this.poseName));
    this.model.presentationT = this.stateT;
    this.model.presentationMode = "victory";
    this.model.glaivePose = this.kit === "glaive" ? (this.state === S.WIN ? "show_baton" : this.poseName) : "idle";
    this.updateKiraCastVisual();
    this.updateKaedeSheathVisual();
    this.model.blend(this.state === S.WIN
      ? presentationPose(this.look.name, this.stateT, this.poses.idle, "victory")
      : (this.poses[this.poseName] ?? this.poses.idle), dt, this.poseSpeed, this.actionPoseTag());
    // Pull the model upright smoothly rather than snapping back to standing.
    if (this.state === S.WAKEUP) {
      const t = THREE.MathUtils.clamp(this.stateT / this.wakeupDuration, 0, 1);
      const eased = t * t * (3 - 2 * t);
      this.model.rotation.x = -1.45 * (1 - eased);
    }
    this.bowDraw(dt);
    this.trail.update(dt);
  }

  /** Archer: the string comes back during the wind-up / charge and snaps forward on release. */
  private bowDraw(dt: number) {
    if (this.kit !== "bow") return;
    if (this.state === S.WIN) {
      // Show-off bow draw on the victory animation, with real string/arrow motion.
      this.model.draw = this.stateT >= 0.55 && this.stateT < 1.35
        ? Math.min(1, (this.stateT - 0.55) / 0.32) : 0;
      return;
    }
    const drawing = this.poseName === "bow_w" || this.poseName === "rain_w" || this.poseName === "charge";
    this.model.draw = drawing ? Math.min(this.model.draw + dt * 8, 1) : 0;
  }

  // --- input -> actions ---------------------------------------------------------
  /** Double-tapped direction: a quick burst that dodges hits (6 s cooldown). */
  // FIGHT_ROYALE_KAEDE_THOUSAND_CUTS_LOCK_MISS3_V4
  isKaedeThousandCutsCasting(): boolean {
    return this.kit === "katana" && this.state === S.ATTACK && !!this.atk &&
      this.atk.name === "Thousand Cuts" && this.atk.style === "slashes";
  }
  /** Kira's Hundred Kicks is an immobile hidden casting stance, not a kick animation.
   * The authoritative fighter root remains hittable (invisible != invulnerable).
   */
  isKiraHundredKicksCasting(): boolean {
    return this.kit === "kicks" && this.state === S.ATTACK &&
      this.atkId === "v" && this.atk?.name === "Hundred Kicks";
  }
  /** Kira V remains visible. The existing casting poses play while
   * movement/dash/extra attacks stay locked until the stance finishes. */
  private updateKiraCastVisual() {
    if (this.kit !== "kicks" || this.model.loading) return;
    this.model.visible = true;
  }
  /** Compute sheathing progress locally or from networked attack pose. */
  private updateKaedeSheathVisual() {
    if (this.kit !== "katana") return;
    const casting = this.puppet
      ? this.state === S.ATTACK && this.poseName.startsWith("kaede_sheathe_")
      : this.isKaedeThousandCutsCasting();
    this.model.katanaSheathProgress = casting
      ? Math.min(1, Math.max(0, this.stateT / 0.25)) : 0;
  }
  /** Called only after the THIRD unsuccessful slice on the authoritative host. */
  cancelKaedeThousandCuts() {
    if (!this.isKaedeThousandCutsCasting()) return;
    this.atk = null;
    this.atkId = "";
    this.atkPhase = 0;
    this.buffered = false;
    this.holding = false;
    this.poseOverride = "";
    this.setState(S.IDLE);
    this.model.recoil = Math.max(this.model.recoil, 0.2);
  }

  private readDash() {
    if (this.isKiraHundredKicksCasting()) return;
    if (this.chainBindT > 0 || (this.chainBoundBy && this.chainBoundBy.chainBindT > 0)) return;
    if (this.isKaedeThousandCutsCasting()) return; // committed, immobile cast
    const d = this.intent.dash;
    if (d.lengthSq() < 0.01 || this.dashCd > 0) return;
    if (![S.IDLE, S.BLOCK, S.CHARGE, S.ATTACK].includes(this.state)) return; // dash cancels attacks, not hitstun
    if (this.kit === "hammer" && this.state === S.ATTACK &&
        (this.atk?.name === "Upsie Daisie" || this.atkPhase !== 0 || !this.atk || this.stateT >= this.atk.wind)) return;
    const dir = d.clone().setY(0);
    if (this.stage) { if (Math.abs(dir.x) < 0.3) return; dir.set(Math.sign(dir.x), 0, 0); this.facing = dir.x; }
    dir.normalize();
    if (this.state !== S.IDLE) {
      if (this.state === S.ATTACK) {
        if (this.kit === "hammer" && this.atk?.style === "nesa_heart_slam") {
          this.nesaCCharges = Math.min(3, this.nesaCCharges + 1);
          if (this.nesaCCharges === 3) this.nesaCRechargeT = 0;
          this.cooldowns[this.atkId] = 0;
        }
        if (this.kit === "hammer") {
          this.atk = null; this.atkId = ""; this.comboNext = "l1"; this.comboTimer = 0;
          this.buffered = false;
        } else this.finishAttack();
      }
      this.holding = false; this.setState(S.IDLE);
    }
    this.dashDir.copy(dir);
    this.dashT = DASH_T;
    this.dashCd = DASH_CD;
    this.invulnT = Math.max(this.invulnT, 0.15); // existing dash i-frames
    this.perfectDodgeT = 0.13; // strict timing; not the full dash duration
    this.perfectDodgeUsed = false;
    this.onDash(this);
  }
  dashing() { return this.dashT > 0; }

  private readAttack(dt: number) {
    const on = this.intent.attack;
    const pressed = on && !this.atkPrev;
    const released = !on && this.atkPrev;
    this.atkPrev = on;
    if (this.isKaedeThousandCutsCasting() || this.isKiraHundredKicksCasting()) {
      this.holding = false; return;
    }
    if ([S.HITSTUN, S.STAGGER, S.KO, S.WIN].includes(this.state)) {
      this.holding = false; this.nesaAirHolding = false; return;
    }
    if (pressed && this.atkLock > 0 && !this.hasParryCounterReady()) return;
    if (pressed && this.parryRecoilT > 0) return;
    // NESA_MOMENTUM_V3: charge a directional midair hammer strike instead of auto-slicing.
    if (this.kit === "hammer" && !this.stage && !this.onGround &&
        (this.state === S.IDLE || this.state === S.BLOCK || this.nesaAirHolding)) {
      if (pressed && !this.airSliceUsed && !this.nesaAirHolding) {
        this.nesaAirHolding = true; this.nesaAirChargeT = 0;
        this.holding = false;
      }
      if (this.nesaAirHolding) {
        if (on) this.nesaAirChargeT = Math.min(0.88, this.nesaAirChargeT + dt);
        if (released || this.nesaAirChargeT >= 0.88) this.nesaReleaseAirStrike();
        return;
      }
    }
    // Airborne left-click is an ordinary basic swing, even without Space held.
    // No launcher, no chain, no chase jump, and no ground smash.
    if (this.kit === "hammer" && !this.stage && pressed && this.onGround && this.intent.jump) {
      this.nesaAirHolding = true; this.nesaAirChargeT = 0;
      this.holding = false; return;
    }
    if (!this.stage && pressed && this.onGround && this.intent.jump &&
        (this.state === S.IDLE || this.state === S.BLOCK)) {
      this.airSliceQueued = true; this.holding = false; return;
    }
    if (!this.stage && pressed && !this.onGround) {
      this.holding = false;
      if (this.kit === "kicks" && this.state === S.ATTACK &&
          /^air_l[1-3]$/.test(this.atkId) && this.kiraAirKicks < 3) {
        // Queue the next click during a kick; fire it when the active contact ends.
        this.kiraAirBuffered = true;
      } else if (this.kit === "assassin" && this.state === S.ATTACK &&
          this.atkId === "air_l1" && this.nyxAirStrikes < 2) {
        // Buffer second tap during Falling Fang; release into Shadow Cross on recovery.
        this.nyxAirBuffered = true;
      } else this.tryAirSlice();
      return;
    }
    if (pressed && this.kit === "glaive" && this.state === S.ATTACK &&
        this.atkId === "l4" && this.atk?.next === "l5") this.buffered = true;
    if (pressed && this.tryParryCounter()) return;
    if (pressed) { this.holding = true; this.holdT = 0; }
    if (this.holding) {
      this.holdT += dt;
      if (this.holdT >= HOLD_T && this.state === S.IDLE && !this.intent.block) this.setState(S.CHARGE);
    }
    if (released && this.holding) {
      this.holding = false;
      if (this.state === S.CHARGE) this.startAttack("heavy");
      else if (this.holdT < HOLD_T) this.requestLight();
    }
  }

  private readJump() {
    // In 3D arena mode Space is always a jump, never an automatic launcher.
    if (this.stage) { this.readJumpPlat(); return; }
    const pressed = this.intent.jump && !this.jumpPrev;
    this.jumpPrev = this.intent.jump;
    if (pressed && this.onGround && (this.state === S.IDLE || this.state === S.BLOCK)) {
      this.velY = this.jumpV;
      this.onGround = false;
      this.airSliceUsed = false; this.kiraAirKicks = 0; this.kiraAirBuffered = false; this.nyxAirStrikes = 0; this.nyxAirBuffered = false;
      if (this.state === S.BLOCK) this.setState(S.IDLE);
      // Space+Click on the same frame: jump, then swing (never anti-air launch).
      if (this.kit === "hammer" && this.nesaAirHolding) this.nesaAirChargeT = 0;
      else if (this.airSliceQueued) this.tryAirSlice();
    } else if (pressed && !this.onGround && this.kit === "wind" && this.airJump < 1 && this.state === S.IDLE) {
      // Double jump: a second push of wind in mid-air.
      this.airJump++;
      this.airJumpT = 0.45;
      this.velY = this.jumpV * 0.75;
      this.model.recoil = 0.3;
      this.onAirJump(this);
    }
  }

  /** KAIZEN_SERPENT_SLAM_V10: animated grappling, no instant teleports. */
  private animateSerpentBound(owner: Fighter, dt: number) {
    const t = Math.max(0, owner.chainBindFinishDuration - owner.chainBindFinishT);
    const forward = owner.stage ? new THREE.Vector3(owner.facing, 0, 0) :
      new THREE.Vector3(Math.sin(owner.root.rotation.y), 0, Math.cos(owner.root.rotation.y));
    // Side view: use the combat line instead of shoving fighters into invisible depth.
    const side = owner.stage ? forward.clone() : new THREE.Vector3(forward.z, 0, -forward.x);
    const origin = owner.root.position;
    const back = owner.chainResolveDirection === "backward";
    // Each pose: [time, forward offset, sideways offset, vertical lift, body tilt].
    const frames: number[][] = back ? [
      [0.23, 1.05, 0, 0.18, 0],
      [0.47, 0.20, 0, 1.65, 0.55],
      [0.72, -0.90, 0.50, 0.04, 0.88],
      [0.90, -0.20, 0.0, 1.10, -0.50],
      [1.15, -1.05, -0.50, 0.04, -0.90],
      [1.34, -0.10, 0, 1.50, 0.30],
      [1.65, -1.25, 0, 0.05, -0.80],
      [1.85, -1.35, 0, 0.05, 0]
    ] : [
      [0.23, 1.08, 0, 0.18, 0],
      [0.46, 0.90, 0, 1.72, -0.45],
      [0.71, 0.78, -0.90, 0.05, -0.95],
      [0.88, 0.80, -0.15, 1.16, 0.48],
      [1.17, 0.88, 0.90, 0.05, 0.95],
      [1.36, 0.90, 0, 1.62, -0.40],
      [1.65, 1.03, 0, 0.05, 0.75],
      [1.85, 1.10, 0, 0.05, 0]
    ];
    const from = [0, 0, 0, 0, 0];
    let prev = from, next = frames[0], prevT = 0;
    if (t > frames[0][0]) {
      for (let i = 0; i < frames.length; i++) {
        if (t <= frames[i][0] || i === frames.length - 1) {
          next = frames[i];
          prev = i === 0 ? from : frames[i - 1];
          prevT = i === 0 ? 0 : frames[i - 1][0];
          break;
        }
      }
    }
    const u0 = THREE.MathUtils.clamp((t - prevT) / Math.max(0.001, next[0] - prevT), 0, 1);
    const u = u0 * u0 * (3 - 2 * u0); // eased acceleration/recoil
    const value = (i: number) => THREE.MathUtils.lerp(prev[i], next[i], u);
    // First segment reels the victim from exactly where the bind caught them.
    const p = origin.clone().addScaledVector(forward, value(1)).addScaledVector(side, value(2));
    p.y += value(3);
    if (t < frames[0][0]) p.lerpVectors(owner.chainBindStartPos, p, u);
    if (this.stage) {
      p.x = THREE.MathUtils.clamp(p.x, this.stage.blast.l + 1, this.stage.blast.r - 1);
      p.z = owner.root.position.z;
    } else {
      const radial = Math.hypot(p.x, p.z);
      if (radial > this.arenaRadius) { p.x *= this.arenaRadius / radial; p.z *= this.arenaRadius / radial; }
    }
    this.root.position.copy(p);
    this.root.rotation.z = value(4); // visible flips as the chain whips the body around
    this.onGround = false;
    this.poseName = t < 0.45 ? "hit" : t < 1.35 ? "stagger" : "hit";
    this.model.blend(this.poses[this.poseName] ?? this.poses.hit ?? this.poses.idle, dt, 28);
  }

  private chainRelativeDirection(): "forward" | "backward" | "left" | "right" | "neutral" {
    const m = this.intent.skillMove ?? this.intent.move;
    if (m.lengthSq() < 0.04) return "neutral";
    if (this.stage) {
      // Side-view: horizontal direction is forward/back relative to current facing.
      if (Math.abs(m.x) > 0.25) return m.x * this.facing > 0 ? "forward" : "backward";
      // Camera up/down is used for jumping/dropping in platform mode; not a side throw.
      return "neutral";
    }
    const forward = new THREE.Vector3(Math.sin(this.root.rotation.y), 0, Math.cos(this.root.rotation.y));
    const front = m.dot(forward), right = m.x * forward.z - m.z * forward.x;
    if (Math.abs(front) >= Math.abs(right)) return front >= 0 ? "forward" : "backward";
    return right >= 0 ? "right" : "left";
  }

  beginChainBind(victim: Fighter, kind: "x" | "v") {
    if (this.chainBindTarget || victim.chainBoundBy || victim.isDown() || this.isDown()) return;
    this.chainBindTarget = victim;
    this.chainBindKind = kind;
    this.chainBindT = 4;
    this.chainChoiceArmed = false; // require a new key press after the bind connects
    this.chainBindFinishT = 0;
    this.chainBindFinishDuration = 0;
    this.chainBindStartPos.copy(victim.root.position);
    this.chainResolveDirection = "";
    victim.chainBoundBy = this;
    this.chainHookTarget = victim;
    this.chainHookT = 0;
    this.velY = 0; this.vx = 0; this.knock = 0;
    victim.velY = 0; victim.vx = 0; victim.knock = 0;
    this.model.chainBindTargetWorld = victim.chest();
    if (kind === "x" && this.state === S.ATTACK) {
      this.finishAttack();
      this.setState(S.IDLE);
    }
  }

  releaseChainBind() {
    const victim = this.chainBindTarget;
    if (victim && victim.chainBoundBy === this) {
      victim.chainBoundBy = null;
      victim.root.rotation.z = 0; // restore upright posture after the cinematic
    }
    this.chainBindTarget = null;
    this.chainBindKind = "";
    this.chainBindT = 0;
    this.chainChoiceArmed = false;
    this.chainBindFinishT = 0;
    this.chainBindFinishDuration = 0;
    this.chainResolveDirection = "";
    // KAIZEN_BIND_FOLLOWUP_V7: prevent the selection key firing after release.
    this.intent.skill = "";
    this.model.chainBindTargetWorld = null;
    if (this.state === S.ATTACK) {
      this.finishAttack();
      this.setState(S.IDLE);
    }
  }

  private readSkill() {
    if (this.isKaedeThousandCutsCasting() || this.isKiraHundredKicksCasting()) return;
    const k = this.intent.skill;
    if (!k || !["z", "x", "c", "v"].includes(k)) return;
    // Prevent key spoofing, old remapped skills and online requests from using locked V.
    if (k === "v" && !this.bonusSkillUnlocked) return;
    // While bound, Z/X are handled in update() before readSkill(); other skills are locked.
    if (this.chainBindT > 0 || (this.chainBoundBy && this.chainBoundBy.chainBindT > 0)) return;
    // C: Blood Festival shuts off ALL active skills (Z/X/C/V) for its full 6 seconds.
    if (this.kit === "sickle" && this.bloodFestivalT > 0) return;
    // Blood Sickle can be steered once after launch, regardless of cooldown.
    if (this.kit === "sickle" && this.sickleOut && this.attacks[k]?.style === "bloodsickle") {
      if (![S.HITSTUN, S.STAGGER, S.KO, S.WIN].includes(this.state)) this.onSickleRecast(this);
      return;
    }
    // A second Z recalls the SAME spear without ignoring the original cooldown.
    if (this.look.element === "metal" && this.zenithSpearOut && k === "z") {
      if (![S.HITSTUN,S.STAGGER,S.KO,S.WIN].includes(this.state)) this.onZenithRecall(this);
      return;
    }
    // Garrick C second press: legal ONLY after the first eruption really hit.
    if (this.kit === "greatsword" && this.attacks[k]?.name === "Titan Cleave" &&
        this.garrickFollowT > 0 && this.garrickFollowTarget &&
        !this.garrickFollowTarget.isDown() && this.onGround &&
        [S.IDLE, S.BLOCK, S.ATTACK].includes(this.state) &&
        (this.state !== S.ATTACK || this.atk?.name === "Titan Cleave" || this.atkPhase === 2)) {
      this.garrickRushTarget = this.garrickFollowTarget;
      this.garrickFollowTarget = null;
      this.garrickFollowT = 0;
      this.holding = false;
      this.startAttack("garrick_follow");
      this.garrickRushSerial = this.swingSerial;
      return;
    }
    // Powder keg out: the same key is the detonator (works any time you're not stunned).
    if (this.barrelOut && this.attacks[k]?.type === "barrel") {
      if (![S.HITSTUN, S.STAGGER, S.KO, S.WIN].includes(this.state)) this.onTrigger(this);
      return;
    }
    if (this.kit === "hammer" && this.attacks[k]?.style === "nesa_heart_slam" &&
        (!this.nesaCArmed || this.nesaCCharges <= 0)) return;
    if ((this.cooldowns[k] ?? 1) > 0) return;
    const free = [S.IDLE, S.BLOCK, S.CHARGE].includes(this.state) || (this.state === S.ATTACK && this.atkPhase === 2);
    if (!free) return;
    this.holding = false;
    if (this.kit === "chainblade") this.chainSkillDir = this.chainRelativeDirection();
    // A mine charge only spends after a legal cast; two deployed mines is a hard cap.
    const bobMine = this.kit === "bomb" && this.attacks[k]?.type === "mine";
    if (bobMine) {
      if (this.bobMineCharges <= 0 || this.bobMineCount >= 2) return;
      const wasFull = this.bobMineCharges === 4;
      this.bobMineCharges -= 1;
      if (wasFull) this.bobMineRechargeT = Math.max(0.2, this.attacks[k].cd * this.cdMult);
    }
    // The keg's cooldown starts when it explodes (the arena sets it).
    if (this.kit === "hammer" && this.attacks[k]?.style === "nesa_heart_slam") {
      this.nesaCArmed = false;
      if (this.nesaCCharges === 3) this.nesaCRechargeT = 7.5 * this.cdMult;
      this.nesaCCharges--;
      this.cooldowns[k] = this.nesaCCharges > 0 ? 0 : this.nesaCRechargeT;
    } else this.cooldowns[k] = this.attacks[k].type === "barrel" ? 0.6 :
      bobMine ? (this.bobMineCharges > 0 ? 0 : this.bobMineRechargeT) : this.attacks[k].cd * this.cdMult;
    // Cast in the air, a skill with an air version uses it instead.
    if (this.look.element === "metal" && k === "c") this.zenithDominionRepel = false; // V9 C is a timed self-buff
    this.startAttack(!this.onGround && this.attacks[k + "_air"] ? k + "_air" : k);
  }

  // AIR_COMBAT_V1: pressed light combos in the air, buffering the next strike.
  private requestAirLight() {
    if (this.onGround) return;
    if (this.state === S.IDLE || this.state === S.BLOCK) this.startAttack("air_l1");
    else if (this.state === S.ATTACK && this.atkId.startsWith("air_l") && this.atk?.next)
      this.buffered = true;
  }

  /** Called by the authoritative arena only after an anti-air actually connects. */
  landedAntiAir(target: Entity) {
    if (target.isDown()) return;
    this.airChaseTarget = target;
    this.airChaseT = 1.15;
    this.airChaseUsed = false;
  }

  private startAirChase() {
    const target = this.airChaseTarget;
    if (!target || target.isDown() || this.airChaseT <= 0) return;
    const toward = target.root.position.clone().sub(this.root.position).setY(0);
    if (toward.lengthSq() < 0.01) toward.set(Math.sin(this.root.rotation.y), 0, Math.cos(this.root.rotation.y));
    this.airChaseDir.copy(toward.normalize());
    if (this.stage) this.airChaseDir.set(Math.sign(target.root.position.x - this.root.position.x) || this.facing, 0, 0);
    this.airChaseMoveT = 0.30;
    this.velY = Math.max(this.jumpV * (this.stage ? 1.43 : 1.32),
      Math.sqrt(Math.max(0, target.root.position.y - this.root.position.y) * 2 * GRAVITY));
    this.onGround = false;
    this.ground = null;
    this.airChaseT = 0;
    this.airChaseUsed = true;
    this.holding = false;
    this.atk = null;
    this.atkId = "";
    this.setState(S.IDLE);
    this.model.recoil = 0.3;
  }

  private tryAirRecovery() {
    const pressed = this.intent.block && !this.airRecoverPrev;
    this.airRecoverPrev = this.intent.block;
    if (!pressed || this.onGround || this.airRecoverUsed || this.state !== S.HITSTUN || this.stateT < 0.18) return;
    // Deliberately one escape only: no infinite air-teching or invulnerable flight.
    this.airRecoverUsed = true;
    this.invulnT = Math.max(this.invulnT, 0.16);
    this.velY = Math.max(this.velY, 1.6);
    this.knock = 0;
    if (this.stage) this.vx = -this.facing * this.moveSpeed * 1.3;
    this.model.recoil = 0.65;
    this.setState(S.IDLE);
  }

  private requestLight() {
    if (this.parryRecoilT > 0) return;
    if (this.tryParryCounter()) return;
    if (this.state === S.IDLE || this.state === S.BLOCK) this.startAttack(this.comboTimer > 0 ? this.comboNext : "l1");
    else if (this.state === S.ATTACK && this.atk && this.atk.next) this.buffered = true;
  }

  private startAttack(id: string) {
    if (id === "pc" && this.parryCounterTarget && !this.parryCounterTarget.isDown()) {
      const aim = this.parryCounterTarget.root.position.clone().sub(this.root.position);
      if (this.stage) {
        const dx = Math.sign(aim.x);
        if (dx) this.facing = dx;
      } else if (aim.lengthSq() > 0.0001) {
        this.root.rotation.y = Math.atan2(aim.x, aim.z);
      }
    }
    // Platform mode: with no direction held, turn toward a nearby foe before swinging.
    if (this.stage && Math.abs(this.intent.move.x) < 0.2 && this.opponent && !this.opponent.isDown()) {
      const dx = this.opponent.root.position.x - this.root.position.x;
      if (Math.abs(dx) < 6 && Math.abs(dx) > 0.05) this.facing = Math.sign(dx);
    }
    this.atkPower = 1;
    if (id === "heavy" && this.state === S.CHARGE) this.atkPower = 1 + 0.5 * Math.min(this.stateT / CHARGE_MAX, 1);
    this.atkPower *= this.dmgMult * (this.rageT > 0 ? RAGE_MULT : 1) * this.status.dmgMult();
    // Aster deals 15% less damage from all attacks. Judgment mechanics remain unchanged.
    if (this.kit === "knight" && this.look.element === "light") this.atkPower *= 0.85;
    if (this.kit === "knight" && this.look.element === "light" && this.judgmentT > 0) {
      const defenseToOffense = Math.min(0.45, this.maxGuard / 100 * 0.35);
      const missingLifeBonus = Math.max(0, 1 - this.hp / Math.max(1, this.maxHp)) * 0.20;
      this.atkPower *= (1 + defenseToOffense + missingLifeBonus);
    }
    // Veyr: during the 6-second Blood Festival, his LIGHT combo hits 35% harder.
    // Heavy attacks and special skills do not receive this bonus.
    if (this.kit === "sickle" && this.bloodFestivalT > 0 && /^l\d+$/.test(id)) this.atkPower *= 1.35;
    // Unbound Drive expands BASIC reach but does not bypass blocks, parries, or clashes.
    // NYX_SMOKE_BOOST: next offensive move only. An ordinary l1..l4, air light,
    // charged heavy or basic parry-riposte gets x2. A damaging skill gets x1.2.
    // Smoke Step itself and non-damaging skills cannot consume the reward.
    if (this.kit === "assassin" && this.nyxShadowBoostT > 0) {
      const chosen = this.attacks[id];
      const isBasic = /^(l[1-9]\d*|air_l[1-9]\d*|pc)$/.test(id);
      // FIGHT_ROYALE_NYX_SMOKE_HEAVY_1P2_V3: charged heavy is x1.2, never x2.
      const isSkill = /^(z|x|c|v)(?:_air)?$/.test(id) && !!chosen && chosen.dmg > 0 &&
        chosen.type !== "buff" && chosen.type !== "blink";
      if (chosen && (isBasic || isSkill || id === "heavy")) {
        this.atkPower *= isBasic ? 2.0 : 1.2;
        this.nyxShadowBoostT = 0;
        this.model.flash(isBasic ? "#b05eff" : "#b1aaff", 0.20);
      }
    }
    this.atkId = id;
    this.atk = this.attacks[id];
    if (this.kit === "hammer" && this.atk?.style === "nesa_high_striker") this.nesaHighStrikerParried = false;
    if (this.kit === "katana" && this.atk?.name === "Thousand Cuts" && this.atk.style === "slashes") {
      this.atk = { ...this.atk, lunge: 0, recover: Math.max(this.atk.recover,
        this.atk.delay + Math.max(0, this.atk.repeat - 1) * this.atk.interval + 0.23) };
      this.dashT = 0; this.holding = false; this.velY = Math.min(0, this.velY);
      this.vx = 0; // stop lingering platform momentum at the start of casting
    }
    if (id === "pc") {
      this.parryCounterDepth = this.parryCounterPendingDepth;
      this.parryCounterT = 0; this.parryCounterTarget = null;
    }
    // AIR_COMBAT_V1: avoid missing pose names on custom character rigs.
    if (!this.atk) { this.atkId = ""; return; }
    if (this.kit === "knuckles" && this.atk?.name === "Meteor Fist") this.knock = 0;
    if (this.kit === "chainblade" && this.chainFuryT > 0 && /^l\d+$/.test(id))
      this.atk = { ...this.atk, reach: this.atk.reach + 0.32, guard: this.atk.guard * 1.12 };
    // Each real clash adds +20% light-combo speed, capped at 2x. Counter itself is uncapped.
    if (this.kit === "glaive" && this.look.element !== "metal" && /^l[1-9]$/.test(id)) {
      const speed = 1 + Math.min(this.clashMomentum, 5) * 0.20;
      this.atk = { ...this.atk, wind: this.atk.wind / speed,
        active: this.atk.active / speed, recover: this.atk.recover / speed };
    }
    // V12 attack speed: twin blades 2x normally / 2.4x with Magnetic Charge;
    // spear basics 1x normally / 2.4x with Magnetic Charge.
    // No animation-only speed fakery; wind, active, and recover ALL scale.
    if (this.kit === "glaive" && this.look.element === "metal" && /^l[1-5]$/.test(id)) {
      const charged = this.zenithMagneticChargeT > 0;
      // ZENITH_MAGNETIC_CHARGE_24X_V12_20261108 — effective multiplier vs original speed.
      const speed = this.zenithSpearOut ? (charged ? 2.4 : 2) : (charged ? 2.4 : 1);
      this.atk = { ...this.atk,
        wind: this.atk.wind / speed,
        active: this.atk.active / speed,
        recover: this.atk.recover / speed,
        guard: this.atk.guard * (charged ? 0.8 : 1),
      };
    }
    if (this.kit === "sickle" && this.bloodFrenzyT > 0 && id.startsWith("l"))
      this.atk = { ...this.atk, wind: this.atk.wind * 0.88, recover: this.atk.recover * 0.88 };
    if (this.kit === "hammer" && id === "heavy") {
      // The spin persists for precisely the time earned by holding the charge.
      const held = THREE.MathUtils.clamp(this.holdT, HOLD_T, 1.75);
      const spin = (0.34 + (held - HOLD_T) * 0.77) * 0.75; // Nesa V6: hold:spin conversion 1:0.75
      this.nesaChargeSeconds = held;
      this.atk = { ...this.atk, active: spin, recover: 0.42,
        dmg: 32 + Math.round(held * 8), reach: 2.58 + held * 0.06,
        knock: 1.8 + held * 0.25, style: "nesa_spin", no_parry: true };
    }
    if (this.kit === "hammer" && id === "air_l1") {
      // A single airborne hammer hit, scaling damage and knockback with hold seconds.
      const ratio = THREE.MathUtils.clamp(this.nesaAirChargedSeconds / 0.88, 0, 1);
      // NESA V5: the jump release is a REAL horizontal weapon spin, not a slice.
      // 1s earned spin becomes 0.75s, as on the ground; shorter hold = fewer revolutions.
      const airSpin = (0.34 + ratio * 0.76) * 0.75;
      this.atk = { ...this.atk, type: "melee", wind: 0.11, active: airSpin,
        recover: 0.30, dmg: 44 + 9 * ratio, knock: 3.8 + 3.4 * ratio,
        guard: 23 + 13 * ratio, reach: 2.55, lunge: 0.5,
        stun: 0.20 + ratio * 0.22, heavy: false,
        style: "nesa_air_spin", no_parry: true, next: "" };
      this.nesaAirChargedSeconds = 0;
    }
    // ASTER_JUDGMENT_BLADE_SPEED_WEAKEN_V1_20261108
    // During Judgment, every real blade swing/cut executes at 1.5x speed.
    // Clone the active attack only: do not permanently speed up the kit data,
    // change cooldowns, or affect shield bashes and non-Aster characters.
    // Successful hits use the existing 50s, max-5-stack Weaken status system.
    if (this.kit === "knight" && this.look.element === "light" &&
        this.judgmentT > 0 && this.atk &&
        (/^(?:l\d+|air_l\d+|heavy|air_heavy|pc)$/.test(id) || id === "x" || id === "c")) {
      const judgmentSpeed = 1.5;
      this.atk = {
        ...this.atk,
        wind: this.atk.wind / judgmentSpeed,
        active: this.atk.active / judgmentSpeed,
        recover: this.atk.recover / judgmentSpeed,
        // This is one application on confirmed damage, not another application
        // layered over the X/C skills which already apply Weaken normally.
        effect: "weaken", effect_t: 50, effect_p: 0.8,
      };
    }
    this.atkPhase = 0;
    this.buffered = false;
    this.comboDamageMult = 1;
    this.comboPauseT = 0;
    this.kaizenSpinSpeed = 1;
    this.kaizenSpinDirection = 1;
    this.kaizenSpinTimerScale = 1;
    this.swingSerial++;
    if (this.atk.self_jump > 0 && this.atk.mode !== "leap" &&
        !(this.kit === "hammer" && this.atk.name === "Upsie Daisie")) {
      this.velY = this.atk.self_jump * (this.stage ? 1.35 : 1);
      this.onGround = false; this.ground = null;
    }
    this.setState(S.ATTACK);
  }

  private attackStep() {
    const a = this.atk!;
    const w = a.wind, ac = a.active, r = a.recover;
    // NESA_DODGE_KIRA_AIR_3_V1: click-buffered second/third kicks during one jump.
    // Each starts a new real attack with its own collision and clash checks.
    if (this.kit === "kicks" && this.kiraAirBuffered && !this.onGround &&
        /^air_l[1-3]$/.test(this.atkId) && this.kiraAirKicks < 3 &&
        this.stateT >= w + ac) {
      this.kiraAirBuffered = false;
      this.kiraAirKicks++;
      this.airSliceUsed = this.kiraAirKicks >= 3;
      this.airSliceAngle = this.airAimAtOpponent();
      this.startAttack(`air_l${this.kiraAirKicks}`);
      return;
    }

    if (this.kit === "assassin" && this.nyxAirBuffered && !this.onGround &&
        this.atkId === "air_l1" && this.nyxAirStrikes < 2 &&
        this.stateT >= w + ac) {
      // A new attack instance: the second cut must hit on its own merits.
      this.nyxAirBuffered = false;
      this.nyxAirStrikes = 2;
      this.airSliceUsed = true;
      this.airSliceAngle = this.airAimAtOpponent();
      this.startAttack("air_l2");
      return;
    }

    if (this.kit === "hammer" && a.name !== "Upsie Daisie" && this.atkPhase === 0 &&
        this.stateT < w && this.intent.block) {
      // Pre-swing cancel is intentional; this move did NOT deal any damage.
      // Refund a stored Heart Smash charge, but only before its impact window.
      if (a.style === "nesa_heart_slam") {
        this.nesaCCharges = Math.min(3, this.nesaCCharges + 1);
        if (this.nesaCCharges === 3) this.nesaCRechargeT = 0;
        this.cooldowns[this.atkId] = 0;
      }
      this.atk = null; this.atkId = ""; this.buffered = false;
      this.holding = false; this.comboNext = "l1"; this.comboTimer = 0;
      this.setState(S.BLOCK);
      return;
    }
    if (a.mode === "leap" || a.mode === "dive") {
      // Leap attack: wind-up crouch -> jump toward the target -> the hit lands on touchdown.
      // Dive: from the air, plunge down (toward the target) -> the hit lands on touchdown.
      if (this.atkPhase === 0 && this.stateT >= w) {
        this.atkPhase = 1;
        const o = this.opponent;
        if (a.mode === "dive") {
          this.velY = -a.speed;
          const air = Math.max(this.root.position.y / a.speed, 0.08);
          if (o && !o.isDown()) {
            const to = o.root.position.clone().sub(this.root.position).setY(0);
            const d = Math.max(to.length() - 0.9, 0);
            this.leapVel.copy(to.normalize().multiplyScalar(Math.min(d / air, a.lunge)));
          } else this.leapVel.set(0, 0, 0);
        } else {
          this.velY = a.self_jump * (this.stage ? 1.35 : 1);
          this.onGround = false;
          this.ground = null;
          const air = (2 * this.velY) / GRAVITY;
          if (o && !o.isDown()) {
            const to = o.root.position.clone().sub(this.root.position).setY(0);
            const d = Math.max(to.length() - 0.9, 0);
            this.leapVel.copy(to.normalize().multiplyScalar(Math.min(d / air, 9)));
          } else this.leapVel.set(Math.sin(this.root.rotation.y), 0, Math.cos(this.root.rotation.y)).multiplyScalar(3);
        }
        if (this.stage) this.vx = this.leapVel.x;
      } else if (this.atkPhase === 1) {
        if (this.onGround && (a.mode === "dive" || this.stateT > w + 0.1)) {
          this.atkPhase = 2;
          this.stateT = w + ac;
          this.leapVel.set(0, 0, 0);
          this.onSwing(this);
        }
      } else if (this.atkPhase === 2 && this.stateT >= w + ac + r) { this.finishAttack(); this.setState(S.IDLE); }
      return;
    }
    if (this.atkPhase === 0 && this.stateT >= w) {
      this.atkPhase = 1;
      if (this.kit === "hammer" && a.name === "Upsie Daisie") {
        // The pole is braced before the kick launches, not after.
        this.velY = Math.max(this.velY, a.self_jump);
        this.onGround = false; this.ground = null;
      }
      if (!this.stage && this.atkId === "air_l1") this.airSliceAngle = this.airAimAtOpponent();
      this.onSwing(this);
    } else if (this.atkPhase === 1 && this.stateT >= w + ac) {
      this.atkPhase = 2;
    } else if (this.atkPhase === 2) {
      if (this.buffered && a.next && this.stateT >= w + ac + Math.min(0.1, r)) this.startAttack(a.next);
      else if (this.intent.block && this.stateT >= w + ac + 0.06) { this.finishAttack(); this.setState(S.BLOCK); }
      else if (this.stateT >= w + ac + r) { this.finishAttack(); this.setState(S.IDLE); }
    }
  }

  private finishAttack() {
    const a = this.atk!;
    if (/^l\d$/.test(this.atkId) && !a.next && a.type !== "melee") this.atkLock = RANGED_COMBO_REST[this.kit] ?? 1.2;
    this.comboNext = a.next || "l1";
    this.comboTimer = a.next ? 0.45 : 0;
  }

  private setState(s: S) {
    if (s === S.BLOCK && this.state !== S.BLOCK) {
      this.shieldRaise = this.nextShieldFast ? 0.01 : 0.10;
      this.nextShieldFast = false;
    }
    this.state = s; this.stateT = 0; this.poseOverride = "";
  }
  /** Pose forced by the arena during an attack (e.g. each kick of a teleport combo). */
  poseOverride = "";

  // --- movement ---------------------------------------------------------------------
  /** Only Kaizen's sustained chainblade spins unlock walk movement. */
  private kaizenCanWalkWhileSpinning() {
    return this.kit === "chainblade" && this.onGround && this.state === S.ATTACK &&
      this.atkPhase <= 1 && !!this.atk &&
      ["chain_razor_cyclone", "chain_death_spiral", "chain_carousel"].includes(this.atk.style);
  }
  private move(dt: number) {
    if (this.isKiraHundredKicksCasting()) {
      this.model.walk = 0; this.model.rotation.y = this.viewBias; return;
    }
    if (this.isKaedeThousandCutsCasting()) {
      this.model.walk = 0; this.model.rotation.y = this.viewBias; return;
    }
    const pos = this.root.position;
    const o = this.opponent;
    let dir = new THREE.Vector3(Math.sin(this.root.rotation.y), 0, Math.cos(this.root.rotation.y));
    let dist = 99;
    if (o && !o.isDown()) {
      const to = o.root.position.clone().sub(pos);
      to.y = 0;
      dist = to.length();
      dir = to.divideScalar(Math.max(dist, 0.001));
    } else if (this.intent.move.lengthSq() > 0.01) {
      dir = this.intent.move.clone().normalize();
    }
    if (this.state !== S.KO) {
      const target = Math.atan2(dir.x, dir.z);
      let d = target - this.root.rotation.y;
      d = Math.atan2(Math.sin(d), Math.cos(d));
      this.root.rotation.y += d * (1 - Math.exp(-12 * dt));
    }
    if (this.state === S.ATTACK && (this.atk?.mode === "leap" || this.atk?.mode === "dive") && this.atkPhase === 1) {
      pos.addScaledVector(this.leapVel, dt);
      const fl = Math.hypot(pos.x, pos.z);
      if (fl > this.arenaRadius) { pos.x *= this.arenaRadius / fl; pos.z *= this.arenaRadius / fl; }
      this.model.rotation.y = this.viewBias;
      return;
    }
    if (this.airChaseMoveT > 0 && !this.onGround) {
      pos.addScaledVector(this.airChaseDir, Math.min(this.moveSpeed * 3.1, 12) * dt);
      const flat = Math.hypot(pos.x, pos.z);
      if (flat > this.arenaRadius) { pos.x *= this.arenaRadius / flat; pos.z *= this.arenaRadius / flat; }
      return;
    }
    if (this.dashT > 0) {
      pos.addScaledVector(this.dashDir, DASH_SPEED * dt);
      const fl = Math.hypot(pos.x, pos.z);
      if (fl > this.arenaRadius) { pos.x *= this.arenaRadius / fl; pos.z *= this.arenaRadius / fl; }
      if (this.state !== S.KO) this.model.rotation.y = this.viewBias;
      return;
    }
    let v = 0;
    let walking = false;
    // No brain yet = still in the READY countdown: stand still.
    if (this.state === S.IDLE && this.autoApproach && this.brain && o && !o.isDown() && dist > ENGAGE) { v = this.walkSpeed * (this.meteorFistArmor ? 1 : this.status.speedMult()) * this.garrickAdvanceFactor(); walking = true; }
    if (this.state === S.ATTACK && this.atk && this.atkPhase <= 1 && dist > MIN_DIST + 0.15) {
      if (this.kit === "hammer" && /^l[1-4]$/.test(this.atkId)) {
        // The next swing shuffles after the knockback with deliberate weighted steps.
        const gap = Math.max(0, dist - this.atk.reach * 0.74);
        const max = this.atk.lunge + (this.atkId === "l1" ? 0 : 1.1);
        v += Math.min(max, 0.85 + gap * 1.28) * (this.atkPhase === 0 ? 0.46 : 1.75);
      } else if (this.kit === "hammer" && this.atk?.name === "Upsie Daisie") {
        // Plant during wind-up; use the fast active kick for the forward burst.
        v += this.atkPhase === 0 ? 0 : Math.min(10.5, this.atk.lunge * 1.4);
      } else if (this.kit === "hammer" && this.atkId === "heavy" && this.atk.style === "nesa_spin") {
        // Each hammer revolution takes a short step toward a recoiling opponent.
        v += this.atkPhase === 0 ? 0.35 : Math.min(5.5, 1.65 + Math.max(0, dist - 2.1) * 2.1);
      } else if (this.kit === "glaive" && this.atk.style === "glaive_thunderflash") {
        // Zenitsu-like real straight-line flash: no movement during preparation.
        // 38 m/s applies only to the short active window, stops at melee contact.
        v += this.atkPhase === 1 ? this.atk.lunge : 0;
      } else v += this.atk.lunge;
    }
    // Garrick Iron Tempest: genuine travel across three consecutive hit windows.
    // The current target direction is recalculated each frame (limited steering).
    if (this.kit === "greatsword" && this.state === S.ATTACK &&
        this.atk?.style === "iron_tempest" && this.onGround && this.atkPhase <= 1) {
      const t = this.stateT - this.atk.wind;
      const stride = t >= 0.58 && t < 0.88 ? 7.2 :
        t >= 0.28 && t < 0.55 ? 5.2 : t >= -0.035 && t < 0.22 ? 3.0 : 0;
      v += stride;
      if (this.intent.move.lengthSq() > 0.1 && stride > 0 && !this.stage) {
        const desired = this.intent.move.clone().setY(0).normalize();
        if (desired.dot(dir) > 0.05) dir.lerp(desired, 0.22).normalize();
      }
    }
    // Garrick Titan Cleave recast: rush through real distance, stopping before contact.
    if (this.kit === "greatsword" && this.state === S.ATTACK &&
        this.atk?.style === "garrick_rush_finish" && this.garrickRushTarget &&
        !this.garrickRushTarget.isDown() && this.garrickRushSerial === this.swingSerial) {
      const to = this.garrickRushTarget.root.position.clone().sub(pos).setY(0);
      const gap = to.length();
      if (gap > 1.90 && this.stateT < this.atk.wind) {
        dir.copy(to.divideScalar(Math.max(0.001, gap)));
        v = Math.min(17.0, (gap - 1.90) / Math.max(0.018, dt));
        if (!this.stage) {
          const yaw = Math.atan2(dir.x, dir.z);
          let delta = yaw - this.root.rotation.y;
          delta = Math.atan2(Math.sin(delta), Math.cos(delta));
          this.root.rotation.y += delta * Math.min(1, dt * 7.5);
        }
      } else v = 0;
    }
    const recoilSpeed = this.knock;
    this.knock = Math.max(this.knock - 13 * dt, 0);
    if (dist < MIN_DIST && v > 0) v = 0;
    pos.addScaledVector(dir, v * dt);
    // Directional collision impulse. Gravity and regular forward movement still work.
    if (recoilSpeed > 0) pos.addScaledVector(this.knockAway, recoilSpeed * dt);
    // NESA_AI_EDGE_GIANT_KIRA_AIR_MOVE_V2: steer Kira during all three airborne kicks.
    // No extra i-frames, dash, or sprint: movement uses her ordinary moveSpeed.
    const kiraAirSteer = this.kit === "kicks" && !this.onGround && this.state === S.ATTACK &&
      /^air_l[1-3]$/.test(this.atkId);
    const nyxAirSteer = this.kit === "assassin" && !this.onGround && this.state === S.ATTACK &&
      /^air_l[1-2]$/.test(this.atkId);
    // Spinning chainblade skills unlock walking while preserving Kira/Nyx aerial steering.
    const steer = this.state === S.IDLE ? 1 : this.state === S.BLOCK ? 0.5 :
      this.state === S.CHARGE ? 0.4 : kiraAirSteer ? 0.92 : nyxAirSteer ? 0.63 :
      this.kaizenCanWalkWhileSpinning() ? 0.72 : 0;
    if (steer > 0 && this.intent.move.lengthSq() > 0.0001) {
      const step = this.intent.move.clone().normalize().multiplyScalar(this.moveSpeed * (this.bloodFrenzyT > 0 ? 1.15 : 1) * (this.meteorFistArmor ? 1 : this.status.speedMult()) * (this.intent.sprint && this.state === S.IDLE && this.onGround ? 1.42 : 1) * this.garrickAdvanceFactor() * steer * dt);
      if (dist < MIN_DIST && step.dot(dir) > 0) step.addScaledVector(dir, -step.dot(dir));
      pos.add(step);
      walking = this.onGround;
    }
    if (dist < MIN_DIST * 0.9) pos.addScaledVector(dir, -(MIN_DIST * 0.9 - dist) * 0.5);
    const flat = Math.hypot(pos.x, pos.z);
    if (flat > this.arenaRadius) { pos.x *= this.arenaRadius / flat; pos.z *= this.arenaRadius / flat; }
    this.model.walk = THREE.MathUtils.damp(this.model.walk, walking ? (this.intent.sprint && this.state === S.IDLE && this.onGround ? 1 : 0.64) : 0, 12, dt);
    if (this.state !== S.KO) this.model.rotation.y = this.viewBias;
  }

  private vertical(dt: number) {
    if (this.onGround) return;
    this.velY -= GRAVITY * dt;
    this.root.position.y += this.velY * dt;
    if (this.kit === "hammer" && this.nesaAirHolding && this.velY < 0 &&
        this.root.position.y < 0.52) this.nesaReleaseAirStrike();
    if (this.root.position.y <= 0) {
      this.root.position.y = 0;
      this.velY = 0;
      this.onGround = true;
      this.airSliceUsed = false; this.kiraAirKicks = 0; this.kiraAirBuffered = false; this.nyxAirStrikes = 0; this.nyxAirBuffered = false;
      this.airSliceQueued = false;
      this.airJump = 0;
      this.airRecoverUsed = false;
      this.airStartT = 99;
      this.airChaseMoveT = 0;
      this.model.recoil = 0.35;
      this.onLanded(this);
    }
  }

  teleport(to: THREE.Vector3) {
    if (this.stage) {
      const b = this.stage.blast;
      this.root.position.x = Math.max(b.l + 2, Math.min(b.r - 2, to.x));
      this.invulnT = 0.3;
      if (this.opponent) this.facing = Math.sign(this.opponent.root.position.x - this.root.position.x) || this.facing;
      return;
    }
    const flat = Math.hypot(to.x, to.z);
    const k = flat > this.arenaRadius ? this.arenaRadius / flat : 1;
    this.root.position.set(to.x * k, this.root.position.y, to.z * k);
    this.invulnT = 0.3;
    if (this.opponent) {
      const d = this.opponent.root.position.clone().sub(this.root.position);
      this.root.rotation.y = Math.atan2(d.x, d.z);
    }
  }

  private tickStatus(dt: number) {
    if (this.state === S.KO || this.state === S.WIN || this.stage) { this.status.clear(); return; }
    const st = this.status.tick(dt, this.model.walk > 0.3);
    if (this.zenithCatchShieldT > 0) {
      for (const cc of ["freeze", "paralyze", "slow"] as const) this.status.consume(cc);
    }
    if (this.status.has("freeze")) {
      this.intent.attack = false; this.intent.skill = ""; this.intent.block = false; this.intent.jump = false;
      this.intent.move.set(0, 0, 0); this.intent.dash.set(0, 0, 0);
      if (this.state !== S.HITSTUN) { this.stun = 2; this.setState(S.HITSTUN); }
      this.stun = Math.max(this.stun, this.stateT + 0.09);
      this.velY = 0; this.knock = 0;
    }
    for (const d of st.dots) {
      this.hp = Math.max(this.hp - d.dmg, 0);
      // Damage-over-time counts as taking damage for guard recovery.
      if (d.dmg > 0) this.guardDelay = GUARD_REGEN_DAMAGE_DELAY;
      this.dots.push({ ...d, src: this.status.src });
      if (this.hp <= 0) { this.ko(); return; }
    }
    if (st.jolt && this.zenithCatchShieldT <= 0 && this.bloodFestivalT <= 0 && !this.meteorFistArmor && !this.hammerWeightArmor && this.state !== S.HITSTUN && this.state !== S.STAGGER) {
      this.stun = 0.25; this.stunPose = "hit"; this.holding = false;
      this.setState(S.HITSTUN);
      this.model.flash("#ffe066", 0.12);
    }
  }

  // --- getting hit --------------------------------------------------------------------
  /** Returns "miss", "warded", "counter", "parry", "blocked", "guard_break", "hit", "crit" or "ko". */
  receiveHit(attacker: Entity | null, a: Attack, power: number): string {
    if (this.state === S.KO) return "none";
    // Grounded knockdown and standing recovery cannot be chained indefinitely.
    // They remain alive; do not mark these states as KO / remove them from the match.
    if (this.knockedDown()) return "miss";
    if (this.invulnT > 0) {
      if (this.perfectDodgeT > 0 && !this.perfectDodgeUsed && this.dashing() &&
          attacker && attacker.team !== this.team && a.dmg > 0) {
        this.perfectDodgeUsed = true; // one trigger even during multi-hit attacks
        this.perfectDodgeT = 0;
        this.perfectDodgeCounterT = 0.95;
        return "perfect_dodge";
      }
      return "miss";
    }
    if (this.look.element === "frost" && this.frostShieldT > 0 && this.frostShieldCharges > 0) {
      this.frostShieldCharges -= 1;
      this.model.recoil = 0.4;
      return "warded"; // zero HP AND guard damage, exactly one crystal spent per hit
    }
    if (this.wardT > 0) { this.model.recoil = 0.4; return "warded"; }
    if (this.counterT > 0 && !a.no_parry) { this.counterT = 0; return "counter"; }
    let dmg = a.dmg * power;
    if (a.type === "projectile" && this.garrickIsAdvancing(attacker)) dmg *= 0.75;
    // Garrick Ground Slam's sword-plant startup is braced, not invulnerable.
    if (this.kit === "greatsword" && this.state === S.ATTACK &&
        this.atk?.name === "Ground Slam" && this.stateT <= this.atk.wind + 0.035)
      dmg *= 0.67;
    // Aster's armor reduces incoming HP damage by 10%, including guard breaks.
    if (this.kit === "knight" && this.look.element === "light") dmg *= 0.90;
    this.knockFrom = attacker ? attacker.root.position.x : this.root.position.x - this.facing;
    // Veyr's Blood Festival forbids the perfect-parry outcome against his melee swings.
    // A regular block still costs guard, and simultaneous attacks can still clash.
    const festivalUnparryable = attacker instanceof Fighter && attacker.kit === "sickle" &&
      attacker.bloodFestivalT > 0 && a.type === "melee";
    // Guard is not instantly active while the shield is still being raised.
    // Extended combos can be parried to soften their following strikes, even
    // if the move was once flagged no_parry. Blood Festival's dedicated immunity
    // remains intact; unrelated single-hit no_parry moves stay unparryable.
    const parryableContinuous = attacker instanceof Fighter && attacker.isContinuousComboActive() &&
      a.style !== "nesa_heart_slam";
    // NESA_FORWARD_HEART_PARRY_V_20261108: actual incoming contact during her vertical V.
    // The first 0.78s is the only parry opportunity; unparryable attacks remain dangerous.
    if (this.kit === "hammer" && this.state === S.ATTACK && this.atk?.style === "nesa_high_striker" &&
        !this.nesaHighStrikerParried && this.stateT >= 0.10 && this.stateT <= 0.79 &&
        attacker && attacker.team !== this.team && (!a.no_parry || parryableContinuous) && !festivalUnparryable) {
      const face = new THREE.Vector3(Math.sin(this.root.rotation.y), 0, Math.cos(this.root.rotation.y));
      const incoming = attacker.root.position.clone().sub(this.root.position).setY(0);
      // Don't catch attacks from directly behind. Projectiles use their shooter direction.
      if (incoming.lengthSq() < 0.15 || incoming.normalize().dot(face) > 0.0) {
        this.nesaHighStrikerParried = true;
        this.model.flash("#ffb7e3", 0.20);
        this.guard = Math.min(this.maxGuard, this.guard + 15);
        return "parry";
      }
    }
    if (this.state === S.BLOCK && this.stateT >= this.shieldRaise) {
      if (this.stateT - this.shieldRaise <= this.parryWindow &&
          (!a.no_parry || parryableContinuous) && !festivalUnparryable) {
        this.guard = Math.min(this.guard + 20, this.maxGuard);
        this.model.flash("#99e6ff", 0.15);
        // Reward applies to the NEXT shield raise, once only; never stack it.
        this.nextShieldFast = true;
        if (a.type === "projectile") this.grantGarrickResolve();
        return "parry";
      }
      // Blood Festival: Veyr's blocked LIGHT sickle hits drain 3x normal guard.
      // power already includes the 1.35x Festival damage buff; cancel that ONLY
      // for guard calculation, then apply the requested 3x guard multiplier.
      // HP damage, clashes, and normal blocks otherwise behave as before.
      const festivalGuardTriple = attacker instanceof Fighter && attacker.kit === "sickle" &&
        attacker.bloodFestivalT > 0 && a.type === "melee" && /^l\d+$/.test(attacker.atkId);
      this.guard -= a.guard * power * (festivalGuardTriple ? 2 / 1.35 : 1) *
        (this.judgmentT > 0 ? 1.5 : 1); // Aster Judgment weakens defense; Veyr nerf unchanged
      this.guardDelay = GUARD_REGEN_DAMAGE_DELAY;
      if (this.guard <= 0) {
        this.guard = 0;
        const hammerCrush = attacker instanceof Fighter && attacker.hammerWeightArmor &&
          (a.type === "melee" || a.type === "strike");
        // NESA_WEIGHT_PASSIVE_V1: late hammer swings still hurt through block and hit harder on guard break.
        this.lastDamage = hammerCrush ? dmg * 0.50 : dmg * 0.4;
        this.lastCrit = false;
        this.hp = Math.max(this.hp - this.lastDamage, 0);
        this.knock = this.zenithCatchShieldT > 0 ? 0 :
          hammerCrush ? Math.max(4.1, a.knock * 0.62) : 3.5;
        if (this.hp <= 0) { this.ko(); return "ko"; }
        if (hammerCrush && !this.stage && this.onGround && this.bloodFestivalT <= 0 &&
            this.knockdownLockT <= 0 && !this.chainBoundBy && !this.chainBindTarget &&
            (a.heavy || a.id === "z" || a.id === "c" || a.id === "v")) this.beginKnockdown();
        else if (this.bloodFestivalT <= 0 && this.zenithCatchShieldT <= 0) this.stagger(0.85);
        this.model.flash("#ffd966", 0.18);
        return "guard_break";
      }
      // KAIZEN_GUARD_CLASH_V8: the spinning chain catches incoming melee weapons.
      // Parry (above) and guard break (above) retain priority; projectiles still block.
      if (this.kit === "chainblade" && attacker instanceof Fighter && a.type === "melee") {
        this.knock = Math.min(a.knock * 0.12, 0.5);
        this.model.recoil = 0.85;
        return "kaizen_guard_clash";
      }
      // NESA_WEIGHT_PASSIVE_V1: late hammer swings crush block into chip damage.
      const hammerCrushBlock = attacker instanceof Fighter && attacker.hammerWeightArmor &&
        a.style !== "nesa_heart_slam" && (a.type === "melee" || a.type === "strike");
      if (hammerCrushBlock) {
        this.lastDamage = dmg * 0.50;
        this.lastCrit = false;
        this.hp = Math.max(0, this.hp - this.lastDamage);
        this.knock = Math.max(this.knock, a.knock * 0.72);
        if (this.hp <= 0) { this.ko(); return "ko"; }
        if (!this.stage && this.onGround && this.knockdownLockT <= 0 &&
            this.bloodFestivalT <= 0 && !this.chainBoundBy && !this.chainBindTarget &&
            (a.heavy || a.id === "z" || a.id === "c" || a.id === "v"))
          this.beginKnockdown();
        else if (!this.stage && this.bloodFestivalT <= 0)
          this.stagger(Math.max(0.20, Math.min(0.45, a.stun * 0.55)));
        this.model.recoil = 0.95;
        return "blocked";
      }
      this.knock = this.zenithCatchShieldT > 0 ? 0 : a.knock * 0.5;
      this.model.recoil = 0.7;
      return "blocked";
    }
    const cc = attacker && (attacker as any).critChance !== undefined ? (attacker as any).critChance : 0.2;
    this.lastCrit = Math.random() < cc;
    if (this.lastCrit) dmg *= 1.6;
    // An unblocked hit also restarts guard recovery, even if the guard bar
    // itself did not change. Arena and platform combat use the same rule.
    if (dmg > 0) this.guardDelay = GUARD_REGEN_DAMAGE_DELAY;
    if (this.stage) return this.launch(attacker, a, dmg);
    this.lastDamage = dmg;
    this.hp = Math.max(this.hp - dmg, 0);
    this.knock = this.meteorFistArmor ? 0 : a.knock;
    this.model.flash();
    if (this.hp <= 0) { this.ko(); return "ko"; }
    // Even during Blood Festival, damage and non-stunning conditions still land.
    if (a.effect && this.zenithCatchShieldT <= 0 &&
        !(this.bloodFestivalT > 0 && a.effect === "paralyze") &&
        !(this.meteorFistArmor && (a.effect === "paralyze" || a.effect === "slow")))
      this.status.apply(a.effect as StatusKind, a.effect_t, a.effect_p, attacker);
    if (this.zenithCatchShieldT > 0) {
      // Damage still lands; no stun, stagger, floor knockdown or forced knockback.
      this.knock = 0;
      this.model.recoil = Math.max(this.model.recoil, 0.18);
      return this.lastCrit ? "crit" : "hit";
    }
    if (this.hammerWeightArmor) {
      // NESA_WEIGHT_PASSIVE_V1: once her swing is committed, Nesa still takes damage,
      // but the weight keeps the attack going instead of letting hitstun cancel it.
      this.knock = Math.min(this.knock, 1.4);
      this.model.recoil = Math.max(this.model.recoil, 0.36);
      return this.lastCrit ? "crit" : "hit";
    }
    // ASTER_EMBER_LATEST_20261106: no repetitive hitstun from passive ground fire.
    if (a.id === "ember_ground") return this.lastCrit ? "crit" : "hit";
    // A heavy physical hit may cause a recoverable floor knockdown. Skills that
    // already control airborne victims, active binds, superarmor, and platform
    // fighter launches intentionally keep their established rules.
    const strongGroundHit = this.onGround && !this.stage && !this.meteorFistArmor &&
      this.bloodFestivalT <= 0 && this.knockdownLockT <= 0 &&
      !this.chainBoundBy && !this.chainBindTarget &&
      a.type === "melee" && a.knock >= 5.3 && (a.heavy || a.stagger);
    if (strongGroundHit) {
      this.beginKnockdown();
      return this.lastCrit ? "crit" : "hit";
    }
    // Stun rules: one stun per skill use (multi-hit skills don't re-stun every tick), and
    // repeated stuns within a few seconds get shorter, so nobody can be locked forever.
    const src = attacker instanceof Fighter
      ? `${attacker.id}:${attacker.swingSerial}${a.id === "z_return" ? ":rail-return" : ""}` : "";
    const reeling = this.state === S.HITSTUN || this.state === S.STAGGER;
    if (src && src === this.stunSrc && reeling) return this.lastCrit ? "crit" : "hit";
    this.stunSrc = src;
    this.stunChain = this.clock - this.lastStunAt < STUN_DR_WINDOW ? this.stunChain + 1 : 0;
    this.lastStunAt = this.clock;
    const stun = Math.max(0.1, a.stun * Math.pow(STUN_DR, this.stunChain));
    if (this.bloodFestivalT <= 0 && !this.meteorFistArmor) {
      if (a.heavy || a.stagger) this.stagger(stun);
      else { this.stun = stun; this.stunPose = "hit"; this.holding = false; this.setState(S.HITSTUN); }
    }
    return this.lastCrit ? "crit" : "hit";
  }

  stagger(d: number) { if (this.zenithCatchShieldT > 0 || this.knockedDown() || this.bloodFestivalT > 0 || this.meteorFistArmor || this.hammerWeightArmor) return; this.stun = d; this.stunPose = "stagger"; this.holding = false; this.setState(S.STAGGER); }

  clashRecoil() {
    if (this.zenithCatchShieldT > 0) { this.model.recoil = 0.30; return; }
    if (this.hammerWeightArmor) {
      // NESA_WEIGHT_PASSIVE_V1: late hammer swings power through clashes.
      this.model.recoil = Math.max(this.model.recoil, 0.32);
      this.knock = Math.max(this.knock, 1.4);
      return;
    }
    if (this.isContinuousComboActive()) {
      // Clash does not interrupt the remaining hits or pause their timeline.
      this.comboDamageMult = Math.max(0.35, this.comboDamageMult * 0.95);
      this.model.recoil = Math.max(this.model.recoil, 0.24);
      return;
    }
    if (this.meteorFistArmor) {
      this.model.recoil = Math.max(this.model.recoil, 0.25);
      return; // Clash counted; Meteor Fist keeps going without being crowd-controlled.
    }
    if (this.bloodFestivalT > 0) {
      // Clash still counts. Cancel the swing and give a short physical recoil,
      // without applying stun (Blood Festival's 3-second immunity).
      this.atk = null; this.atkId = ""; this.atkPhase = 0;
      this.buffered = false; this.holding = false; this.knock = 2.2;
      this.model.recoil = 1;
      this.setState(S.IDLE);
      return;
    }
    this.stun = 0.38; this.stunPose = "clash"; this.holding = false; this.knock = 4; this.model.recoil = 1;
    this.setState(S.HITSTUN);
  }

  pushBack(speed: number) { if (!this.meteorFistArmor && !this.hammerWeightArmor) this.knock = Math.max(this.knock, speed); }
  win() { if (this.state !== S.KO) this.setState(S.WIN); }

  revive(frac: number) {
    this.garrickResolve = 0;
    this.bobMineCharges = 4; this.bobMineRechargeT = 0; this.bobMineCount = 0;
    this.garrickFollowT = 0; this.garrickFollowTarget = null; this.garrickRushTarget = null;
    this.nyxShadowBoostT = 0;
    this.releaseChainBind();
    if (this.chainBoundBy) this.chainBoundBy.releaseChainBind();
    this.chainBoundBy = null;
    this.airChaseT = 0; this.airChaseMoveT = 0; this.airRecoverUsed = false;
    this.airSliceUsed = false; this.kiraAirKicks = 0; this.kiraAirBuffered = false; this.nyxAirStrikes = 0; this.nyxAirBuffered = false; this.airSliceQueued = false;
    this.nesaAirHolding = false; this.nesaAirChargeT = 0; this.nesaSpinYaw = 0;
    this.nesaCCharges = 3; this.nesaCRechargeT = 0; this.nesaCArmed = true;
    this.model.nesaSpinHorizontal = 0;
    this.parryCounterT = 0; this.parryCounterTarget = null; this.parryCounterSpin = 0;
    this.model.parryCounterSpin = 0;
    this.parryRecoilT = 0; this.parryCounterPendingDepth = 0; this.parryCounterDepth = 0; this.counterVisualRemote = false;
    this.hp = this.maxHp * frac;
    this.guard = this.maxGuard;
    this.guardDelay = 0; // Fresh round: no guard recovery penalty carries over.
    this.chainFuryT = 0;
    this.judgmentT = 0; this.model.setJudgment(false);
    this.clashMomentum = 0;
    if (this.look.element === "metal") {
      this.zenithSpearOut = false;
      this.zenithMagneticChargeT = 0;
      this.zenithCatchShieldT = 0;
      this.zenithCatchRecoilT = 0;
      this.model.zenithCatchShieldT = 0;
      this.model.zenithCatchRecoilT = 0;
      this.model.setZenithSpearHeld(true);
    }
    this.bloodlust = 0; this.bloodFrenzyT = 0; this.bloodFeintT = 0; this.sickleOut = false; this.bloodFestivalT = 0;
    this.model.standUp();
    this.knock = 0; this.knockdownLockT = 0;
    this.setState(S.IDLE);
  }

  heal(amount: number) { this.hp = Math.min(this.hp + amount, this.maxHp); }

  ko() {
    this.garrickResolve = 0;
    this.garrickFollowT = 0; this.garrickFollowTarget = null; this.garrickRushTarget = null;
    this.nyxShadowBoostT = 0;
    this.nextShieldFast = false; this.shieldRaise = 0.10;
    this.comboPauseT = 0; this.comboDamageMult = 1;
    this.judgmentT = 0; this.model.setJudgment(false);
    this.releaseChainBind();
    if (this.chainBoundBy) this.chainBoundBy.releaseChainBind();
    this.chainBoundBy = null;
    this.airChaseT = 0; this.airChaseMoveT = 0;
    this.airSliceUsed = false; this.kiraAirKicks = 0; this.kiraAirBuffered = false; this.nyxAirStrikes = 0; this.nyxAirBuffered = false; this.airSliceQueued = false;
    this.nesaAirHolding = false; this.nesaAirChargeT = 0; this.nesaSpinYaw = 0;
    this.nesaCCharges = 3; this.nesaCRechargeT = 0; this.nesaCArmed = true;
    this.model.nesaSpinHorizontal = 0;
    this.parryCounterT = 0; this.parryCounterTarget = null; this.parryCounterSpin = 0;
    this.model.parryCounterSpin = 0;
    this.parryRecoilT = 0; this.parryCounterPendingDepth = 0; this.parryCounterDepth = 0; this.counterVisualRemote = false;
    this.clashMomentum = 0;
    this.bloodlust = 0; this.bloodFrenzyT = 0; this.bloodFeintT = 0; this.sickleOut = false; this.bloodFestivalT = 0;
    this.status.clear();
    this.setState(S.KO);
    this.model.fall();
    this.onKo(this);
  }

  // --- platform fighter -----------------------------------------------------------------
  /** Damage % and knockback: launch speed grows with the % already taken. */
  private launch(attacker: Entity | null, a: Attack, dmg: number): string {
    const p = dmg * PCT_PER_DMG;
    this.pct = Math.min(this.pct + p, 999);
    this.lastDamage = p;
    if (this.zenithCatchShieldT > 0) {
      this.model.flash();
      return this.lastCrit ? "crit" : "hit";
    }
    if (this.meteorFistArmor) {
      this.model.flash();
      return this.lastCrit ? "crit" : "hit";
    }
    const speed = 2.5 + a.knock * 0.5 + this.pct * (0.06 + p * 0.006);
    let side = Math.sign(this.root.position.x - (attacker ? attacker.root.position.x : this.knockFrom));
    if (!side) side = attacker instanceof Fighter ? attacker.facing : -this.facing;
    const ang = THREE.MathUtils.degToRad(a.self_jump > 0 ? 72 : a.heavy ? 42 : 34);
    this.vx = side * speed * Math.cos(ang);
    const vy = speed * Math.sin(ang);
    if (vy > 3 || !this.onGround) { this.velY = Math.max(this.velY * 0.2, vy); this.onGround = false; this.ground = null; }
    this.model.flash();
    this.holding = false;
    this.stun = 0.18 + speed * 0.032;
    this.stunPose = speed > 9 || a.heavy ? "stagger" : "hit";
    if (this.bloodFestivalT <= 0) this.setState(S.HITSTUN);
    return this.lastCrit ? "crit" : "hit";
  }

  private readJumpPlat() {
    const want = this.intent.jump || this.up();
    const pressed = want && !this.upPrev;
    this.upPrev = want;
    if (!pressed || ![S.IDLE, S.BLOCK, S.CHARGE].includes(this.state)) return;
    if (this.onGround) {
      this.velY = this.jumpV * 1.32;
      this.onGround = false;
      this.ground = null;
      if (this.state === S.BLOCK) this.setState(S.IDLE);
    } else if (this.airJumps > 0) {
      this.airJumps--;
      this.velY = this.jumpV * 1.15;
      const mx = this.intent.move.x;
      if (Math.abs(mx) > 0.2) { this.vx = Math.sign(mx) * this.moveSpeed * 1.2; this.facing = Math.sign(mx); }
      this.model.recoil = 0.3;
    }
  }

  private movePlat(dt: number) {
    if (this.isKiraHundredKicksCasting()) {
      this.vx = 0; this.model.walk = 0; return;
    }
    if (this.isKaedeThousandCutsCasting()) {
      this.vx = 0; this.model.walk = 0; return;
    }
    const pos = this.root.position;
    pos.z += (this.lane - pos.z) * Math.min(1, dt * 8);
    const mx = Math.abs(this.intent.move.x) > 0.2 ? Math.sign(this.intent.move.x) : 0;
    const free = this.state === S.IDLE || this.state === S.CHARGE;
    if (this.knock > 0) {
      const o = this.opponent;
      const away = Math.sign(pos.x - (o ? o.root.position.x : this.knockFrom)) || -this.facing;
      this.vx = away * this.knock * 1.3;
      this.knock = 0;
    }
    if (mx && (this.state === S.IDLE || (this.state === S.CHARGE && this.onGround))) this.facing = mx;
    let walking = false;
    if (this.onGround) {
      let target = 0;
      if (free) { target = mx * this.moveSpeed * (this.state === S.CHARGE ? 0.3 : 1.55) * (this.state === S.IDLE && this.onGround && this.intent.sprint ? 1.42 : 1) * this.garrickAdvanceFactor(); walking = mx !== 0; }
      if (this.state === S.ATTACK && this.atk && this.atkPhase <= 1) {
        const o = this.opponent;
        const near = o && !o.isDown() && Math.abs(o.root.position.x - pos.x) < MIN_DIST && Math.abs(o.root.position.y - pos.y) < 1;
        target = near ? 0 : this.facing *
          (this.kit === "glaive" && this.atk.style === "glaive_thunderflash" && this.atkPhase !== 1
            ? 0 : this.atk.lunge);
        // Arena/platform mode: obey actual left/right input during the spin.
        // Don't grant Kaizen any new lunge or attack speed.
        if (this.kaizenCanWalkWhileSpinning()) {
          target = mx * this.walkSpeed * 0.85;
          if (mx) this.facing = mx;
          walking = mx !== 0;
        }
        if (this.kit === "greatsword" && this.atk.style === "iron_tempest") {
          const t = this.stateT - this.atk.wind;
          const extra = t >= 0.58 && t < 0.88 ? 7.2 :
            t >= 0.28 && t < 0.55 ? 5.2 : t >= -0.035 && t < 0.22 ? 3.0 : 0;
          target += this.facing * extra;
          if (mx === this.facing) target += mx * 0.8; // small between-swing steering
        }
        if (this.kit === "greatsword" && this.atk.style === "garrick_rush_finish" &&
            this.garrickRushTarget && !this.garrickRushTarget.isDown() &&
            this.garrickRushSerial === this.swingSerial && this.stateT < this.atk.wind) {
          const dx = this.garrickRushTarget.root.position.x - pos.x;
          if (Math.abs(dx) > 1.8) {
            this.facing = Math.sign(dx);
            target = this.facing * Math.min(17, (Math.abs(dx) - 1.8) / Math.max(dt, 0.018));
          } else target = 0;
        }
      }
      const grip = this.state === S.HITSTUN || this.state === S.STAGGER ? 5 : 16;
      this.vx += (target - this.vx) * (1 - Math.exp(-grip * dt));
    } else if (this.state === S.HITSTUN || this.state === S.STAGGER) {
      this.vx *= Math.exp(-0.6 * dt);
    } else {
      const cap = this.moveSpeed * 1.35;
      if (mx) this.vx += mx * this.moveSpeed * 4 * dt;
      if (Math.abs(this.vx) > cap) this.vx *= Math.exp(-3 * dt);
      else if (!mx) this.vx *= Math.exp(-1.2 * dt);
      if (this.state === S.ATTACK && this.atk && this.atkPhase <= 1 && this.atk.lunge > 3) this.vx = this.facing * Math.max(Math.abs(this.vx), this.atk.lunge * 0.6);
    }
    if (this.dashT > 0) { this.vx = this.dashDir.x * DASH_SPEED * 1.1; if (!this.onGround) this.velY = Math.max(this.velY, 0.5); }
    if (this.airChaseMoveT > 0 && !this.onGround)
      this.vx = this.airChaseDir.x * Math.min(this.moveSpeed * 3.1, 12);
    pos.x += this.vx * dt;
    // Main stage walls: can't pass through its sides.
    for (const p of this.stage!.plats) {
      if (!p.solid || pos.y >= p.y - 0.05 || pos.y < p.y - 4) continue;
      if (pos.x > p.x0 && pos.x < p.x1) {
        pos.x = pos.x - p.x0 < p.x1 - pos.x ? p.x0 : p.x1;
        this.vx = 0;
      }
    }
    if (this.state !== S.KO) {
      const target = this.facing * Math.PI / 2;
      let d = target - this.root.rotation.y;
      d = Math.atan2(Math.sin(d), Math.cos(d));
      this.root.rotation.y += d * (1 - Math.exp(-18 * dt));
      this.model.rotation.y = this.viewBias;
    }
    this.model.walk = THREE.MathUtils.damp(this.model.walk, walking ? (this.intent.sprint && this.state === S.IDLE && this.onGround ? 1 : 0.64) : 0, 12, dt);
  }

  private verticalPlat(dt: number) {
    const pos = this.root.position;
    const st = this.stage!;
    const down = this.down();
    const downPressed = down && !this.downPrev;
    this.downPrev = down;
    this.dropT = Math.max(this.dropT - dt, 0);
    if (this.onGround) {
      const g = this.ground;
      if (!g || pos.x < g.x0 || pos.x > g.x1) { this.onGround = false; this.ground = null; this.velY = 0; }
      else if (downPressed && !g.solid && (this.state === S.IDLE || this.state === S.BLOCK)) {
        this.dropT = 0.3; this.onGround = false; this.ground = null; this.velY = -2; pos.y -= 0.03;
        if (this.state === S.BLOCK) this.setState(S.IDLE);
      } else { pos.y = g.y; return; }
    }
    const prevY = pos.y;
    const tumbling = this.state === S.HITSTUN || this.state === S.STAGGER;
    this.velY -= GRAVITY * dt;
    if (!tumbling) {
      if (down && this.velY < 3 && this.state === S.IDLE) this.velY = Math.min(this.velY, -15); // fast fall
      this.velY = Math.max(this.velY, -16);
    }
    pos.y += this.velY * dt;
    if (this.velY <= 0) {
      for (const p of st.plats) {
        if (pos.x < p.x0 || pos.x > p.x1 || prevY < p.y - 0.001 || pos.y > p.y) continue;
        if (!p.solid && (this.dropT > 0 || (down && this.state === S.IDLE))) continue;
        pos.y = p.y;
        this.velY = 0;
        this.onGround = true;
        this.airSliceUsed = false; this.kiraAirKicks = 0; this.kiraAirBuffered = false; this.nyxAirStrikes = 0; this.nyxAirBuffered = false;
        this.airSliceQueued = false;
        this.ground = p;
        this.airJumps = 1;
        this.airRecoverUsed = false;
        this.airStartT = 99;
        this.airChaseMoveT = 0;
        this.model.recoil = 0.35;
        this.onLanded(this);
        break;
      }
    }
    const b = st.blast;
    if (pos.x < b.l || pos.x > b.r || pos.y < b.b || pos.y > b.t) this.blastOut();
  }

  private blastOut() {
    this.onBlast(this);
    this.stocks--;
    this.out = true;
    this.root.visible = false;
    this.trail.emitting = false;
    this.vx = 0; this.velY = 0; this.knock = 0;
    this.atk = null;
    this.holding = false;
    if (this.stocks <= 0) { this.ko(); return; }
    this.respawnT = 1.4;
  }

  private waitRespawn(dt: number) {
    if (this.state === S.KO) return;
    this.respawnT -= dt;
    if (this.respawnT > 0) return;
    const r = this.stage!.respawn;
    this.root.position.set(r.x + this.lane * 2, r.y, this.lane);
    this.root.visible = true;
    this.out = false;
    this.pct = 0;
    this.onGround = false;
    this.ground = null;
    this.velY = 0;
    this.airJumps = 1;
    this.airRecoverUsed = false;
    this.airChaseT = 0;
    this.airChaseMoveT = 0;
    this.invulnT = 2;
    this.guard = this.maxGuard;
    this.setState(S.IDLE);
    this.model.flash("#ffffff", 0.25);
  }

  // --- posing -------------------------------------------------------------------------
  private computePose() {
    let p = "idle", sp = 14;
    const a = this.atk;
    switch (this.state) {
      case S.IDLE:
        if (!this.onGround) {
          if (this.airJumpT > 0 && this.poses.wind_jump) { p = "wind_jump"; sp = 18; }
          else if (this.kit === "hammer" && this.nesaAirHolding) { p = "charge"; sp = 10; }
          else { p = "jump"; sp = 12; }
        }
        break;
      case S.BLOCK: p = "block"; sp = 30; break;
      case S.CHARGE: p = this.attacks.heavy.pose_w; sp = this.look.element === "metal" ? 22 : 10; break;
      case S.ATTACK:
        if (this.kit === "hammer" && a) {
          if (a.style === "nesa_spin" || a.style === "nesa_air_spin") {
            p = this.atkPhase === 0 ? "charge" : (Math.floor(Math.max(0, this.stateT - a.wind) / 0.19) % 2 === 0 ? "l3_s" : "l2_s");
            sp = this.atkPhase === 0 ? 10 : 72;
          } else if (a.style === "nesa_high_striker") {
            p = this.stateT < a.wind + 0.25 ? "charge" :
              this.stateT < a.wind + 1.74 ? "l3_w" : "heavy_s";
            sp = this.stateT < a.wind + 1.74 ? 12 : 65;
          } else if (this.atkPhase === 0) { p = a.pose_w; sp = 9.5; }
          else if (this.atkPhase === 1) { p = a.pose_s; sp = 65; }
          else { p = a.pose_s; sp = 12; }
          break;
        }
        // NYX_SHADOW_COMBAT_AIR_2_V1: fast dagger contact, compact recover, no wide robotic arms.
        if (this.kit === "assassin" && a) {
          if (this.atkPhase === 0) { p = a.pose_w; sp = 29; }
          else if (this.atkPhase === 1) { p = a.pose_s; sp = 76; }
          else if (this.stateT < a.wind + a.active + a.recover * 0.63) { p = a.pose_s; sp = 23; }
          else { p = "idle"; sp = 19; }
          break;
        }
        if (this.poseOverride) { p = this.poseOverride; sp = 40; break; }
        // ASTER_KNIGHT_COMBAT_ANIM_V2: visual anticipation, explosive contact, shield-first reset.
        // No changes to attackStep(), active windows, lunge, collision or damage.
        if (this.kit === "knight" && this.look.element === "light" && a) {
          if (this.atkPhase === 0) { p = a.pose_w; sp = 19; }
          else if (this.atkPhase === 1) { p = a.pose_s; sp = 76; }
          else if (this.stateT < a.wind + a.active + a.recover * 0.46) {
            p = a.pose_s; sp = 27;
          } else { p = "aster_reset"; sp = 18; }
          break;
        }
        if (a?.mode === "leap" || a?.mode === "dive") {
          if (this.atkPhase === 0) { p = a.pose_w; sp = 16; }
          else if (this.atkPhase === 1) { p = "slam_air"; sp = 14; }
          else { p = a.pose_s; sp = 40; }
          break;
        }
        // VEYR_BLOODLUST_CARRION_V7: animate every slash on host and online clients.
        if (this.kit === "sickle" && a?.style === "sickle_carrion") {
          const elapsed = this.stateT - a.wind;
          p = elapsed < 0 ? "vrv_w" : ["vrv1_s", "vrv2_s", "vrv3_s", "vrv4_s", "vrv5_s"][Math.min(4, Math.floor(elapsed / 0.14))];
          sp = elapsed < 0 ? 22 : 48;
          break;
        }
        // ZENITH_SPEAR_ANIMATION_AUDIO_V2_20261108 — dedicated attack pose timing.
        if (this.kit === "glaive" && this.look.element === "metal" && a) {
          if (a.style === "zenith_barrage") {
            const elapsed = this.stateT - a.wind;
            const combo = this.zenithSpearOut
              ? ["znt1_s", "znt2_s", "znt3_s", "znt4_s", "znt5_s", "zntx_s"]
              : ["zn1_s", "zn2_s", "zn3_s", "zn4_s", "zn5_s", "znx_s"];
            p = elapsed < 0 ? (this.zenithSpearOut ? "znt1_w" : "znx_w") :
              combo[Math.min(5, Math.floor(elapsed / 0.105))];
            sp = elapsed < 0 ? 25 : 67;
          } else if (this.zenithSpearOut && /^l[1-5]$/.test(this.atkId)) {
            p = `znt${this.atkId.slice(1)}_${this.atkPhase === 0 ? "w" : "s"}`;
            sp = this.atkPhase === 0 ? 28 : 80;
          } else if (this.atkPhase === 0) { p = a.pose_w; sp = 25; }
          else if (this.atkPhase === 1) { p = a.pose_s; sp = 74; }
          else if (this.stateT < a.wind + a.active + a.recover * 0.68) { p = a.pose_s; sp = 25; }
          else { p = "idle"; sp = 20; }
          break;
        }
        // ZAREK_CYCLONE_V3: true successive poses for serpent, slide reversal and ultimate.
        if (this.kit === "glaive" && a?.style === "glaive_serpent") {
          const elapsed = this.stateT - a.wind;
          if (elapsed < 0) { p = "glz_w"; sp = 27; }
          else { p = ["glz_s", "gl3_s", "gl2_s", "gl4_s", "glz_s"][Math.min(4, Math.floor(elapsed / 0.21))]; sp = 43; }
          break;
        }
        if (this.kit === "glaive" && a?.style === "glaive_thunderflash") {
          p = this.stateT < a.wind ? "glx_w" : this.stateT < a.wind + a.active ? "glx_turn" : "gl4_s";
          sp = this.stateT < a.wind ? 28 : 72;
          break;
        }
        if (this.kit === "glaive" && a?.style === "glaive_phantom") {
          p = this.stateT < a.wind ? "glx_w" : this.stateT < a.wind + 0.19 ? "gl2_s" : "glx_turn"; sp = 46;
          break;
        }
        if (this.kit === "glaive" && a?.style === "glaive_infinite") {
          const elapsed = this.stateT - a.wind;
          p = elapsed < 0 ? "glc_w" : elapsed < 1.43 ? ["gl1_s", "gl2_s", "gl3_s", "gl4_s", "gl2_s", "gl3_s", "glc_launch"][Math.min(6, Math.floor(elapsed / 0.215))] : "glc_finish";
          sp = elapsed < 0 ? 22 : 55;
          break;
        }
        // ZAREK_GLAIVE_CHOREO_V2: readable windup, fast weapon contact, controlled follow-through.
        if (this.kit === "glaive" && a?.type === "melee") {
          if (this.atkPhase === 0) { p = a.pose_w; sp = 23; }
          else if (this.atkPhase === 1) { p = a.pose_s; sp = 66; }
          else if (this.stateT < a.wind + a.active + a.recover * 0.8) { p = a.pose_s; sp = 18; }
          else { p = "idle"; sp = 13; }
          break;
        }
        if (a?.style === "cyclone_kick_v2") {
          const elapsed = this.stateT - a.wind;
          if (elapsed < 0) { p = "cy1_w"; sp = 24; }
          else if (elapsed < 0.19) { p = "cy1_s"; sp = 50; }
          else if (elapsed < 0.38) { p = "cy2_s"; sp = 55; }
          else { p = "cy3_s"; sp = 55; }
          break;
        }
        if (a?.style === "chain_carousel") {
          const elapsed = this.stateT - a.wind;
          if (elapsed < 0) { p = "cbx_w"; sp = 17; }
          else if (elapsed < 0.19) { p = "cbx1_s"; sp = 38; }
          else if (elapsed < 0.40) { p = "cbx2_s"; sp = 42; }
          else { p = "cbx3_s"; sp = 40; }
          break;
        }
        if (a?.style === "iron_tempest") {
          // Distinct two turning slashes and a full-body heavy horizontal finish.
          const elapsed = this.stateT - a.wind;
          if (elapsed < 0) { p = "charge"; sp = 16; }
          else if (elapsed < 0.30) { p = "l1_s"; sp = 38; }
          else if (elapsed < 0.62) { p = "l2_s"; sp = 40; }
          else { p = "heavy_s"; sp = 36; }
          break;
        }
        if (a?.type === "melee" && ((this.kit === "greatsword" || this.kit === "hammer") ||
            (this.kit === "knight" && this.look.element === "light"))) {
          const heavySword = this.kit === "greatsword" || this.kit === "hammer";
          if (this.atkPhase === 0) { p = a.pose_w; sp = heavySword ? 13 : 24; }
          else if (this.atkPhase === 1) { p = a.pose_s; sp = heavySword ? 28 : 46; }
          else if (this.stateT < a.wind + a.active + a.recover * 0.75) {
            p = a.pose_s; sp = heavySword ? 12 : 22;
          } else { p = "idle"; sp = heavySword ? 8 : 13; }
          break;
        }
        if (this.atkPhase === 0) { p = a!.pose_w; sp = 22; }
        else if (this.atkPhase === 1) { p = a!.pose_s; sp = 45; }
        else if (this.stateT < a!.wind + a!.active + a!.recover * 0.5) { p = a!.pose_s; sp = 20; }
        else sp = 9;
        break;
      case S.HITSTUN:
      case S.STAGGER: p = this.stunPose; sp = 28; break;
      case S.KO: p = "down"; sp = 10; break;
      case S.KNOCKDOWN: p = "down"; sp = 18; break;
      case S.WAKEUP: p = "rise"; sp = 14; break;
      case S.WIN: p = "win"; sp = 6; break;
    }
    // Directional air swings use real distinct poses, including for remote VRM models.
    if (!this.stage && this.state === S.ATTACK && (this.atkId === "air_l1" || (this.kit === "kicks" && /^air_l[2-3]$/.test(this.atkId)) ||
        (this.kit === "assassin" && this.atkId === "air_l2"))) {
      const direction = this.airSliceAngle < -0.28 ? "down" :
        this.airSliceAngle > 0.28 ? "up" : "level";
      if (this.kit === "kicks") {
        const number = Math.max(1, Math.min(3, Number(this.atkId.slice(-1)) || 1));
        p = `kira_air_${number}_${direction}_${this.atkPhase === 0 ? "w" : "s"}`;
      } else if (this.kit === "assassin") {
        p = `nyx_air_${this.atkId === "air_l2" ? 2 : 1}_${direction}_${this.atkPhase === 0 ? "w" : "s"}`;
      } else p = `air_slice_${direction}_${this.atkPhase === 0 ? "w" : "s"}`;
      sp = this.atkPhase === 0 ? (this.kit === "assassin" ? 34 : 24) : (this.kit === "assassin" ? 74 : 56);
    }
    if (this.look.element === "metal" && this.zenithCatchRecoilT > 0 &&
        this.state !== S.KO && this.state !== S.WIN) {
      p = this.zenithCatchRecoilT > 0.34 ? "zncatch_w" : "zncatch_s";
      sp = this.zenithCatchRecoilT > 0.34 ? 32 : 24;
    }
    this.poseName = p;
    this.poseSpeed = sp;
  }

  // --- networking -----------------------------------------------------------------------
  /** Compact state sent from the host to clients. */
  snapshot(): any[] {
    const p = this.root.position;
    return [this.id, +p.x.toFixed(3), +p.y.toFixed(3), +p.z.toFixed(3), +this.root.rotation.y.toFixed(3),
      this.state, this.poseName, this.poseSpeed, Math.round(this.hp), Math.round(this.guard),
      +this.model.walk.toFixed(2), +this.model.charge.toFixed(2), this.trail.emitting ? 1 : 0,
      +this.model.recoil.toFixed(2), this.cooldowns.z, this.cooldowns.x, this.cooldowns.c, this.maxHp,
      +this.pct.toFixed(1), this.stocks, this.out ? 1 : 0, +this.atkLock.toFixed(2), +this.dashCd.toFixed(2), this.status.mask, this.barrelOut ? 1 : 0, Math.round(this.bloodlust), +this.bloodFrenzyT.toFixed(2), this.sickleOut ? 1 : 0, +this.bloodFestivalT.toFixed(2), +this.tempestSpin.toFixed(3), +this.cycloneSpin.toFixed(3), +this.bladeSwingYaw.toFixed(3), +this.chainFuryT.toFixed(2), this.clashMomentum, this.chainBindTarget ? +this.chainBindTarget.chest().x.toFixed(2) : null, this.chainBindTarget ? +this.chainBindTarget.chest().y.toFixed(2) : null, this.chainBindTarget ? +this.chainBindTarget.chest().z.toFixed(2) : null, +this.chainBindT.toFixed(2), +this.judgmentT.toFixed(2), +this.comboDamageMult.toFixed(3), +this.comboPauseT.toFixed(2), +this.stateT.toFixed(3),
      +this.nesaSpinYaw.toFixed(3), +this.model.nesaHammerScale.toFixed(2),
      this.nesaCCharges, +this.nesaCRechargeT.toFixed(2), +this.model.nesaSpinHorizontal.toFixed(2),
      +this.parryCounterSpin.toFixed(3), this.atkId === "pc" ? 1 : 0,
      +this.kaizenSpinSpeed.toFixed(2), this.kaizenSpinDirection, this.garrickResolve, +this.cooldowns.v.toFixed(2), this.frostShardStacks, this.frostShieldCharges, +this.frostShieldT.toFixed(2),
      this.zenithSpearOut ? 1 : 0, +this.zenithCatchShieldT.toFixed(2), +this.zenithCatchRecoilT.toFixed(2),
      +this.zenithMagneticChargeT.toFixed(2)];
  }

  applySnapshot(s: any[]) {
    this.netPos.set(s[1], s[2], s[3]);
    this.netRot = s[4];
    const prev = this.state;
    this.state = s[5];
    this.poseName = s[6];
    this.poseSpeed = s[7];
    if (s.length > 41) this.stateT = s[41];
    this.nesaSpinYaw = s.length > 42 ? s[42] : 0;
    this.model.nesaHammerScale = s.length > 43 ? s[43] : 1;
    this.nesaCCharges = s.length > 44 ? s[44] : 3;
    this.nesaCRechargeT = s.length > 45 ? s[45] : 0;
    this.model.nesaSpinHorizontal = s.length > 46 ? s[46] : 0;
    this.parryCounterSpin = s.length > 47 ? s[47] : 0;
    this.model.parryCounterSpin = this.parryCounterSpin;
    this.counterVisualRemote = s.length > 48 && s[48] === 1;
    // Appended fields: older snapshots default to normal clockwise speed.
    this.kaizenSpinSpeed = s.length > 49 ? s[49] : 1;
    this.kaizenSpinDirection = s.length > 50 ? s[50] : 1;
    this.garrickResolve = s.length > 51 ? s[51] : 0;
    // Roxy V5 fields appended; backward-compatible with older server snapshots.
    this.frostShardStacks = s.length > 53 ? s[53] : 0;
    this.frostShieldCharges = s.length > 54 ? s[54] : 0;
    this.frostShieldT = s.length > 55 ? s[55] : 0;
    if (this.look.element === "metal" && s.length > 58) {
      const isOut = s[56] === 1;
      if (this.zenithSpearOut !== isOut) {
        this.zenithSpearOut = isOut;
        this.model.setZenithSpearHeld(!isOut);
      }
      this.zenithCatchShieldT = s[57] ?? 0;
      this.zenithCatchRecoilT = s[58] ?? 0;
      this.model.zenithCatchShieldT = this.zenithCatchShieldT;
      this.model.zenithCatchRecoilT = this.zenithCatchRecoilT;
      this.zenithMagneticChargeT = s.length > 59 ? (s[59] ?? 0) : 0;
    }
    this.hp = s[8];
    this.guard = s[9];
    this.model.walk = s[10];
    this.model.charge = s[11];
    this.trail.emitting = s[12] === 1;
    this.model.recoil = Math.max(this.model.recoil, s[13]);
    this.cooldowns.z = s[14]; this.cooldowns.x = s[15]; this.cooldowns.c = s[16];
    this.cooldowns.v = s.length > 52 ? s[52] : 0;
    this.maxHp = s[17];
    if (s.length > 18) {
      this.pct = s[18]; this.stocks = s[19]; this.atkLock = s[21] ?? 0; this.dashCd = s[22] ?? 0; this.status.mask = s[23] ?? 0; this.barrelOut = s[24] === 1; this.bloodlust = s[25] ?? 0; this.bloodFrenzyT = s[26] ?? 0; this.sickleOut = s[27] === 1; this.bloodFestivalT = s[28] ?? 0; this.clashMomentum = s[33] ?? 0; this.chainFuryT = s[32] ?? 0;
      this.model.chainBindTargetWorld = s.length >= 37 && s[34] !== null
        ? new THREE.Vector3(s[34], s[35], s[36]) : null;
      this.chainBindT = s[37] ?? 0; // KAIZEN_BIND_ZX_V6: remote HUD follow-ups
      this.judgmentT = s[38] ?? 0; // ASTER_EMBER_LATEST_20261106: preserve older fields
      this.comboDamageMult = s[39] ?? 1;
      this.comboPauseT = s[40] ?? 0;
      const out = s[20] === 1;
      if (out !== this.out) { this.out = out; this.root.visible = !out; if (!out) this.root.position.copy(this.netPos); }
    }
    this.tempestSpin = s[29] ?? 0;
    this.cycloneSpin = s[30] ?? 0;
    this.bladeSwingYaw = s[31] ?? 0;
    if (this.state === S.KO && prev !== S.KO) this.model.fall();
    if (this.state !== S.KO && prev === S.KO) this.model.standUp();
    if (this.state === S.KNOCKDOWN && prev !== S.KNOCKDOWN) this.model.fall();
    if ((prev === S.WAKEUP || prev === S.KNOCKDOWN) &&
        this.state !== S.WAKEUP && this.state !== S.KNOCKDOWN) this.model.standUp();
  }

  private updatePuppet(dt: number) {
    const k = 1 - Math.exp(-15 * dt);
    if (this.root.position.distanceTo(this.netPos) > 3) this.root.position.copy(this.netPos);
    else this.root.position.lerp(this.netPos, k);
    let d = this.netRot - this.root.rotation.y;
    d = Math.atan2(Math.sin(d), Math.cos(d));
    this.root.rotation.y += d * k;
    for (const key in this.cooldowns) this.cooldowns[key] = Math.max(this.cooldowns[key] - dt, 0);
    this.atkLock = Math.max(this.atkLock - dt, 0);
    this.dashCd = Math.max(this.dashCd - dt, 0);
    if (this.state !== S.KO) this.model.rotation.y = this.viewBias + this.tempestSpin + this.cycloneSpin + this.bladeSwingYaw + this.nesaSpinYaw;
    this.model.setBarrier(this.state === S.BLOCK && this.kit === "mage");
    this.model.setJudgment(this.kit === "knight" && this.look.element === "light" && this.judgmentT > 0);
    this.model.combat = [S.ATTACK, S.CHARGE, S.BLOCK, S.HITSTUN, S.STAGGER].includes(this.state);
    this.model.hurt = this.state === S.HITSTUN || this.state === S.STAGGER;
    this.model.bloodFestivalT = this.kit === "sickle" ? this.bloodFestivalT : 0;
    this.model.chainFuryT = this.kit === "chainblade" ? this.chainFuryT : 0;
    this.model.kaizenSpinSpeed = this.kaizenSpinSpeed;
    this.model.kaizenSpinDirection = this.kaizenSpinDirection;
    this.model.kaizenSpinActive = this.kit === "chainblade" && this.state === S.ATTACK &&
      this.kaizenSpinSpeed < 1;
    this.model.chainPose = this.kit === "chainblade"
      ? (this.state === S.WIN && this.stateT >= 0.55 && this.stateT <= 2.30 ? "cbz_w" : this.poseName)
      : "idle";
    this.model.chainExtended = this.kit === "chainblade" && (this.chainFuryT > 0 ||
      ["cbz_w", "cbz_s", "cbx_w", "cbx1_s", "cbx2_s", "cbx3_s", "cbh_w", "cbh_s", "cbv_w", "cbv_s"].includes(this.poseName));
    this.model.presentationT = this.stateT;
    this.model.presentationMode = "victory";
    this.model.glaivePose = this.kit === "glaive" ? (this.state === S.WIN ? "show_baton" : this.poseName) : "idle";
    this.updateKiraCastVisual();
    this.updateKaedeSheathVisual();
    this.model.blend(this.state === S.WIN
      ? presentationPose(this.look.name, this.stateT, this.poses.idle, "victory")
      : (this.poses[this.poseName] ?? this.poses.idle), dt, this.poseSpeed, this.actionPoseTag());
    if (this.state === S.WAKEUP) {
      const t = THREE.MathUtils.clamp(this.stateT / this.wakeupDuration, 0, 1);
      this.model.rotation.x = -1.45 * (1 - t * t * (3 - 2 * t));
    }
    this.bowDraw(dt);
    this.trail.update(dt);
  }
}
